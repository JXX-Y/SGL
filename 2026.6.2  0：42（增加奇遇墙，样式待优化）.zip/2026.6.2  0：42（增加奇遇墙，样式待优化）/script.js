// ==================== 数据定义 ====================
const STORAGE_ROLES='r_final', STORAGE_TASKS='t_final', STORAGE_RECORDS='rec_final';
const STORAGE_THEME='theme', STORAGE_CURRENCY='cur_final';
const DEFAULT_TASKS = [
    {id:'t1',name:'大战',category:'PVE',type:'daily',typeName:'日常',defaultReward:150,condition:1,remark:'',assignedRoles:[],repeatType:'daily',repeatDays:[]},
    {id:'t2',name:'矿跑',category:'PVP',type:'daily',typeName:'日常',defaultReward:120,condition:1,remark:'',assignedRoles:[],repeatType:'daily',repeatDays:[]},
    {id:'t3',name:'茶馆',category:'PVX',type:'daily',typeName:'日常',defaultReward:80,condition:1,remark:'',assignedRoles:[],repeatType:'daily',repeatDays:[]},
    {id:'t4',name:'小周常',category:'PVE',type:'smallWeekly',typeName:'小周常',defaultReward:300,condition:1,remark:'周二、周六',assignedRoles:[],repeatType:'custom',repeatDays:[2,6]},
    {id:'t6',name:'大周常',category:'PVE',type:'bigWeekly',typeName:'大周常',defaultReward:500,condition:1,remark:'',assignedRoles:[],repeatType:'weekly',repeatDays:[]}
];
const DEFAULT_ROLES = [
    {id:'r1',server:'唯我独尊',name:'小七',faction:'七秀',bodyType:'成女'},
    {id:'r2',server:'唯我独尊',name:'阿花',faction:'万花',bodyType:'萝莉'},
    {id:'r3',server:'双梦镇',name:'苍爹',faction:'苍云',bodyType:'成男'}
];
const FORTUNES = [
    {text:'大吉 · 紫气东来',icon:'🌟',desc:'今日运势极佳，适合挑战高难度副本'},
    {text:'中吉 · 玉露凝光',icon:'✨',desc:'稳扎稳打，收益可期'},
    {text:'小吉 · 清风拂面',icon:'🍃',desc:'日常清完，闲来可逛交易行'},
    {text:'平 · 云淡风轻',icon:'☁️',desc:'平淡是福，勿忘签到'},
    {text:'小凶 · 雾锁重楼',icon:'🌫️',desc:'今日开支可能偏大，注意攒钱'},
    {text:'中凶 · 剑鸣匣中',icon:'⚔️',desc:'小心翻车，组队时多沟通'}
];
const QUOTES = ['江湖路远，行则将至。','一壶浊酒，一剑天涯。','不忘初心，方得始终。','青山不改，绿水长流。','剑气纵横三万里，一剑光寒十九洲。','事了拂衣去，深藏身与名。'];

let appRoles = JSON.parse(localStorage.getItem(STORAGE_ROLES)) || DEFAULT_ROLES;
let appTasks = JSON.parse(localStorage.getItem(STORAGE_TASKS)) || DEFAULT_TASKS;
let appRecords = JSON.parse(localStorage.getItem(STORAGE_RECORDS)) || {};
let currentTheme = localStorage.getItem(STORAGE_THEME) || 'default';
let currencyData = JSON.parse(localStorage.getItem(STORAGE_CURRENCY)) || {unit:'金',bigUnit:'砖',rate:10000};

// 数据迁移：为旧任务添加重复方式字段
appTasks.forEach(task => {
    if(!task.repeatType){
        if(task.type === 'smallWeekly'){
            task.repeatType = 'custom';
            task.repeatDays = [2,6];
        } else if(task.type === 'bigWeekly'){
            task.repeatType = 'weekly';
            task.repeatDays = [];
        } else if(task.type === 'limited'){
            task.repeatType = 'limited';
            task.repeatDays = [];
        } else {
            task.repeatType = 'daily';
            task.repeatDays = [];
        }
    }
    if(!task.repeatDays) task.repeatDays = [];
    if(!task.typeName){
        const typeMap = {
            'daily': '日常',
            'smallWeekly': '小周常',
            'bigWeekly': '大周常',
            'limited': '限时',
            'custom': '自定义'
        };
        task.typeName = typeMap[task.type] || '';
    }
});
saveAll();

// ==================== 辅助函数 ====================
function formatCurrency(amount){
    const {unit,bigUnit,rate}=currencyData;
    const r=parseInt(rate)||10000;
    if(bigUnit&&r>1&&Math.abs(amount)>=r){
        const big=Math.floor(Math.abs(amount)/r);
        const small=Math.abs(amount)%r;
        return (amount<0?'-':'')+big+bigUnit+(small>0?small+unit:'');
    }
    return amount+unit;
}
function saveAll(){
    localStorage.setItem(STORAGE_ROLES,JSON.stringify(appRoles));
    localStorage.setItem(STORAGE_TASKS,JSON.stringify(appTasks));
    localStorage.setItem(STORAGE_RECORDS,JSON.stringify(appRecords));
}
function genId(){ return 'id_'+Date.now()+'_'+Math.random().toString(36).substr(2,6); }
function escapeHtml(str){
    if(!str) return '';
    return String(str).replace(/[&<>"']/g, function(s){
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s];
    });
}
function getToday(){
    const d = new Date();
    return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
}
function isTaskVisibleForRole(task,roleId){
    return !task.assignedRoles || task.assignedRoles.length===0 || task.assignedRoles.includes(roleId);
}
function getDayOfWeek(date){
    const d = new Date(date+'T00:00:00');
    const day = d.getDay();
    return day===0 ? 7 : day;
}
function isTaskActiveInDate(task, dateStr){
    const dayNum = getDayOfWeek(dateStr);
    const repeatType = task.repeatType || 'daily';
    const repeatDays = task.repeatDays || [];
    
    if(repeatType === 'daily') return true;
    
    if(repeatType === 'workweek'){
        return dayNum >= 1 && dayNum <= 5;
    }
    
    if(repeatType === 'holiday'){
        return dayNum === 6 || dayNum === 7;
    }
    
    if(repeatType === 'custom'){
        return repeatDays.includes(dayNum);
    }
    
    if(repeatType === 'weekly') return true;
    
    if(repeatType === 'limited'){
        if(task.startDate && dateStr < task.startDate) return false;
        if(task.endDate && dateStr > task.endDate) return false;
        return true;
    }
    
    return false;
}
function isTaskCDCompleted(roleId, task, dateStr){
    if(task.type !== 'bigWeekly') return false;
    const dayNum = getDayOfWeek(dateStr);
    const todayStr = getToday();
    if(dateStr > todayStr) return false;
    if(task.type === 'bigWeekly'){
        for(let d=1; d<=7; d++){
            const cdDate = getDateInWeek(dateStr, d);
            if(cdDate && appRecords[`${roleId}_${task.id}_${cdDate}`]) return true;
        }
        return false;
    }
    return false;
}
function getDateInWeek(anyDateInWeek, targetDayNum){
    const d = new Date(anyDateInWeek+'T00:00:00');
    const currentDay = getDayOfWeek(anyDateInWeek);
    const diff = targetDayNum - currentDay;
    d.setDate(d.getDate() + diff);
    return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
}
function parseRecordKey(key){
    const parts = key.split('_');
    if(parts.length < 3) return null;
    const ds = parts[parts.length - 1];
    for(let tlen=1; tlen<=parts.length-2; tlen++){
        const tid = parts.slice(parts.length - 1 - tlen, parts.length - 1).join('_');
        const rid = parts.slice(0, parts.length - 1 - tlen).join('_');
        if(appTasks.some(t => t.id === tid)) return {rid, tid, ds};
    }
    const tid = parts[parts.length - 2];
    const rid = parts.slice(0, parts.length - 2).join('_');
    return {rid, tid, ds};
}
function getLimitedCount(roleId, taskId){
    let count = 0;
    Object.keys(appRecords).forEach(key => {
        const parsed = parseRecordKey(key);
        if(!parsed) return;
        if(parsed.rid === roleId && parsed.tid === taskId) count++;
    });
    return count;
}

// ==================== 标签式多选通用函数 ====================
function renderTagSelect(containerId, items, selectedIds, callbackName) {
    const container = document.getElementById(containerId);
    if (!container) return;
    container.innerHTML = items.map(item => {
        const id = item.id || item.value || item;
        const name = item.name || item.label || item;
        return `<span class="tag-option ${selectedIds.includes(id) ? 'selected' : ''}" data-id="${id}" onclick="handleTagToggle(this, '${containerId}')">${name}</span>`;
    }).join('');
    container.dataset.callback = callbackName;
}
function handleTagToggle(el, containerId) {
    el.classList.toggle('selected');
    const container = document.getElementById(containerId);
    const ids = [...container.querySelectorAll('.tag-option.selected')].map(s => s.dataset.id);
    const cb = container.dataset.callback;
    if (cb && window[cb]) window[cb](ids);
}
function getSelectedTagIds(containerId) {
    return [...document.querySelectorAll(`#${containerId} .tag-option.selected`)].map(s => s.dataset.id);
}

// ==================== 主题 ====================
function setTheme(theme){
    currentTheme=theme;
    localStorage.setItem(STORAGE_THEME,theme);
    if(theme==='default') document.documentElement.removeAttribute('data-theme');
    else document.documentElement.setAttribute('data-theme',theme);
    document.querySelectorAll('.theme-option').forEach(o=>o.classList.remove('active'));
    document.querySelector(`.theme-option[data-theme="${theme}"]`)?.classList.add('active');
}
function initTheme(){
    if(currentTheme!=='default') document.documentElement.setAttribute('data-theme',currentTheme);
    document.querySelector(`.theme-option[data-theme="${currentTheme}"]`)?.classList.add('active');
}

// ==================== 货币设置 ====================
function saveCurrencyUnit(){
    currencyData.unit = document.getElementById('currencyUnit').value.trim() || '金';
    currencyData.bigUnit = document.getElementById('bigUnit').value.trim() || '';
    currencyData.rate = parseInt(document.getElementById('unitRate').value) || 10000;
    localStorage.setItem(STORAGE_CURRENCY,JSON.stringify(currencyData));
    if(document.getElementById('tab-home').classList.contains('active')) renderHome();
    if(document.getElementById('tab-analysis').classList.contains('active')) renderAnalysis();
}

// ==================== 数据导入导出 ====================
function exportData(){
    const data = {
        roles:appRoles, tasks:appTasks, records:appRecords,
        currency:currencyData, theme:currentTheme,
        exportTime:new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(data,null,2)],{type:'application/json'});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `日常管理_备份_${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
}
function importData(){
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = e => {
        const file = e.target.files[0];
        if(!file) return;
        const reader = new FileReader();
        reader.onload = re => {
            try {
                const data = JSON.parse(re.target.result);
                if(!data.roles || !data.tasks || !data.records) return alert('无效文件');
                if(!confirm('导入将覆盖当前所有数据，确定继续？')) return;
                appRoles = data.roles;
                appTasks = data.tasks;
                appRecords = data.records;
                if(data.currency){
                    currencyData = data.currency;
                    localStorage.setItem(STORAGE_CURRENCY,JSON.stringify(currencyData));
                }
                if(data.theme) setTheme(data.theme);
                saveAll();
                alert('导入成功！页面将刷新。');
                location.reload();
            } catch(err) {
                alert('解析失败：'+err.message);
            }
        };
        reader.readAsText(file);
    };
    input.click();
}
function clearHistoryData(){
    const recordCount = Object.keys(appRecords).length;
    if(recordCount === 0){
        alert('当前没有历史数据可以清除。');
        return;
    }
    if(!confirm(`确定要清除所有历史数据吗？\n\n将删除 ${recordCount} 条任务完成记录。\n角色和任务配置将被保留。\n\n此操作不可恢复，建议先导出数据备份！`)) return;
    if(!confirm('最后确认：真的要清除所有历史数据吗？此操作无法撤销！')) return;
    appRecords = {};
    saveAll();
    alert(`已成功清除 ${recordCount} 条历史记录！`);
    renderHome();
    if(document.getElementById('tab-record').classList.contains('active')) renderTaskView();
    if(document.getElementById('tab-analysis').classList.contains('active')) { renderAnalysisRoleCards(); renderAnalysis(); }
}

// ==================== 悬浮菜单 ====================
function toggleFabMenu(){
    const m = document.getElementById('fabMenu');
    m.style.display = m.style.display==='block'?'none':'block';
}
document.addEventListener('click', e => {
    if(!e.target.closest('.fab') && !e.target.closest('.fab-menu'))
        document.getElementById('fabMenu').style.display = 'none';
});
document.getElementById('fabBtn').addEventListener('click', toggleFabMenu);
document.getElementById('btn-add-role').addEventListener('click', ()=>{ toggleFabMenu(); showAddRoleModal(); });
document.getElementById('btn-add-task').addEventListener('click', ()=>{ toggleFabMenu(); showAddTaskModal(); });
document.getElementById('btn-manage-tasks').addEventListener('click', ()=>{ toggleFabMenu(); showManageTasksModal(); });
document.getElementById('btn-manage-roles').addEventListener('click', ()=>{ toggleFabMenu(); showManageRolesModal(); });

function closeModal(){ document.getElementById('modalContainer').innerHTML = ''; }
// ==================== 添加角色模态 ====================
function showAddRoleModal(){
    let html = `<div class="modal-overlay" onclick="closeModal()"><div class="modal" onclick="event.stopPropagation()"><h3>📝 添加角色 <button class="close-btn" onclick="closeModal()">×</button></h3>
        <div class="form-row"><label>区服<input type="text" id="modalServer" placeholder="唯我独尊"></label><label>角色名称<input type="text" id="modalName" placeholder="小七"></label><label>门派<select id="modalFaction"><option value="">请选择</option><option>万花</option><option>七秀</option><option>少林</option><option>天策</option><option>纯阳</option><option>藏剑</option><option>五毒</option><option>唐门</option><option>明教</option><option>丐帮</option><option>苍云</option><option>长歌</option><option>霸刀</option><option>蓬莱</option><option>凌雪阁</option><option>衍天宗</option><option>药宗</option><option>刀宗</option><option>万灵</option><option>段氏</option></select></label><label>体型<select id="modalBodyType"><option value="">请选择</option><option>成男</option><option>成女</option><option>正太</option><option>萝莉</option></select></label></div>
        <button class="btn btn-primary" id="saveRoleBtn">✅ 保存角色</button>
        <div style="margin-top:10px;font-size:0.9rem;color:var(--text-light);">可分配任务（新建时选择，保存后会把角色加入对应任务的分配列表）</div>
        <div id="modalTaskCheckboxes" style="margin-top:8px;display:flex;flex-wrap:wrap;gap:6px;max-height:160px;overflow-y:auto;"></div>
        <div id="modalRoleTags" style="margin-top:10px;display:flex;flex-wrap:wrap;gap:6px;max-height:100px;overflow-y:auto;"></div>
    </div></div>`;
    document.getElementById('modalContainer').innerHTML = html;
    document.getElementById('saveRoleBtn').addEventListener('click', addRoleFromModal);
    updateModalRoleTags();
    updateModalTaskTags();
}
function updateModalRoleTags(){
    const c = document.getElementById('modalRoleTags');
    if(c) c.innerHTML = appRoles.map(r=>`<span class="role-tag">${r.name}（${r.faction}）</span>`).join('');
}
function updateModalTaskTags(){
    const c = document.getElementById('modalTaskCheckboxes');
    if(!c) return;
    c.innerHTML = appTasks.map(t=>`<span class="role-tag task-tag" data-taskid="${t.id}">${t.name}</span>`).join('');
    c.querySelectorAll('.task-tag').forEach(tag=>{
        tag.addEventListener('click', function(){
            this.classList.toggle('selected');
        });
    });
}
function addRoleFromModal(){
    const s = document.getElementById('modalServer').value.trim();
    const n = document.getElementById('modalName').value.trim();
    const f = document.getElementById('modalFaction').value;
    const b = document.getElementById('modalBodyType').value;
    if(!s||!n||!f||!b) return alert('请填写完整');
    const newId = genId();
    appRoles.push({id:newId,server:s,name:n,faction:f,bodyType:b});
    const selectedTaskIds = [...document.querySelectorAll('#modalTaskCheckboxes .task-tag.selected')].map(t=>t.dataset.taskid).filter(Boolean);
    selectedTaskIds.forEach(tid => {
        const task = appTasks.find(t=>t.id===tid);
        if(task){
            task.assignedRoles = task.assignedRoles || [];
            if(!task.assignedRoles.includes(newId)) task.assignedRoles.push(newId);
        }
    });
    saveAll();
    closeModal();
    renderHome();
    renderRecordRoleList();
    if(document.getElementById('taskViewContent').innerHTML) renderTaskView();
}

// ==================== 角色管理模态 ====================
function showManageRolesModal(){
    let html = `<div class="modal-overlay" onclick="closeModal()"><div class="modal" onclick="event.stopPropagation()"><h3>👥 角色管理 <button class="close-btn" onclick="closeModal()">×</button></h3><div id="manageRoleList">${appRoles.length===0?'<p style="color:var(--text-light);text-align:center;">暂无角色</p>':''}${appRoles.map(r=>`<div class="role-manage-card"><div class="role-manage-info"><strong>${r.name}</strong><span style="font-size:0.75rem;color:var(--text-light);"> · ${r.faction} · ${r.bodyType}</span><br><small style="color:var(--text-light);">区服：${r.server}</small></div><div class="role-manage-actions" style="display:flex;gap:6px;"><button class="btn btn-sm edit-role-btn" data-roleid="${r.id}">✏️ 编辑</button><button class="btn btn-sm btn-danger delete-role-btn" data-roleid="${r.id}">🗑 删除</button></div></div>`).join('')}</div></div></div>`;
    document.getElementById('modalContainer').innerHTML = html;
    document.querySelectorAll('.edit-role-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const roleId = btn.dataset.roleid;
            closeModal();
            editRole(roleId);
        });
    });
    document.querySelectorAll('.delete-role-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const roleId = btn.dataset.roleid;
            deleteRole(roleId);
        });
    });
}
function editRole(roleId){
    const role = appRoles.find(r=>r.id===roleId);
    if(!role) return;
    let html = `<div class="modal-overlay" onclick="closeModal()"><div class="modal" onclick="event.stopPropagation()"><h3>✏️ 编辑角色 <button class="close-btn" onclick="closeModal()">×</button></h3>
        <div class="form-row"><label>区服 <input type="text" id="editServer" value="${role.server}"></label><label>角色名称 <input type="text" id="editName" value="${role.name}"></label><label>门派<select id="editFaction">${['万花','七秀','少林','天策','纯阳','藏剑','五毒','唐门','明教','丐帮','苍云','长歌','霸刀','蓬莱','凌雪阁','衍天宗','药宗','刀宗','万灵','段氏'].map(f=>`<option value="${f}" ${role.faction===f?'selected':''}>${f}</option>`).join('')}</select></label><label>体型<select id="editBodyType">${['成男','成女','正太','萝莉'].map(b=>`<option value="${b}" ${role.bodyType===b?'selected':''}>${b}</option>`).join('')}</select></label></div>
        <button class="btn btn-primary" id="saveRoleEditBtn">💾 保存修改</button>
    </div></div>`;
    document.getElementById('modalContainer').innerHTML = html;
    document.getElementById('saveRoleEditBtn').addEventListener('click', () => saveRoleEdit(roleId));
}
function saveRoleEdit(roleId){
    const role = appRoles.find(r=>r.id===roleId);
    if(!role) return;
    const server = document.getElementById('editServer').value.trim();
    const name = document.getElementById('editName').value.trim();
    const faction = document.getElementById('editFaction').value;
    const bodyType = document.getElementById('editBodyType').value;
    if(!server||!name||!faction||!bodyType) return alert('请填写完整信息');
    role.server = server; role.name = name; role.faction = faction; role.bodyType = bodyType;
    saveAll();
    closeModal();
    renderHome();
    renderRecordRoleList();
    if(document.getElementById('tab-analysis').classList.contains('active')) { renderAnalysisRoleCards(); renderAnalysis(); }
    alert('角色信息已更新！');
}
function deleteRole(roleId){
    const role = appRoles.find(r=>r.id===roleId);
    if(!role) return;
    if(!confirm(`确定要删除角色「${role.name}」吗？\n\n删除后该角色的完成记录将被保留，但不再显示。`)) return;
    appRoles = appRoles.filter(r=>r.id!==roleId);
    saveAll();
    showManageRolesModal();
    renderHome();
    renderRecordRoleList();
    if(document.getElementById('tab-analysis').classList.contains('active')) { renderAnalysisRoleCards(); renderAnalysis(); }
}

// ==================== 添加/编辑任务模态 ====================
function showAddTaskModal(editTaskId=null){
    const task = editTaskId ? appTasks.find(t=>t.id===editTaskId) : null;
    const weekDays = [
        {value:1, label:'周一'},
        {value:2, label:'周二'},
        {value:3, label:'周三'},
        {value:4, label:'周四'},
        {value:5, label:'周五'},
        {value:6, label:'周六'},
        {value:7, label:'周日'}
    ];
    const repeatType = task?.repeatType || 'daily';
    const repeatDays = task?.repeatDays || [];
    const category = task?.category || 'PVE';
    const typeName = task?.typeName || '';
    
    let html = `<div class="modal-overlay" onclick="closeModal()"><div class="modal" onclick="event.stopPropagation()" style="max-width:600px;"><h3>${task?'✏️ 编辑任务':'📋 添加任务'} <button class="close-btn" onclick="closeModal()">×</button></h3>
        <div class="form-row">
            <label style="flex:1;">任务名称
                <input type="text" id="modalTaskName" value="${task?.name||''}" style="width:100%;">
            </label>
        </div>
        <div class="form-row">
            <label>一级分类
                <select id="modalTaskCategory">
                    <option value="PVE" ${category==='PVE'?'selected':''}>PVE</option>
                    <option value="PVP" ${category==='PVP'?'selected':''}>PVP</option>
                    <option value="PVX" ${category==='PVX'?'selected':''}>PVX</option>
                </select>
            </label>
            <label style="flex:1;">二级分类
                <input type="text" id="modalTaskTypeName" value="${typeName}" placeholder="例如：日常、小周常、大周常等" style="width:100%;">
            </label>
        </div>
        <div class="form-row">
            <label>默认收益
                <input type="number" id="modalTaskReward" value="${task?.defaultReward||0}" step="0.01">
            </label>
            <label>完成条件
                <input type="number" id="modalTaskCondition" value="${task?.condition||1}" min="1">
            </label>
        </div>
        <div class="form-row">
            <label style="flex:1;">重复方式
                <select id="modalRepeatType" style="width:100%;">
                    <option value="daily" ${repeatType==='daily'?'selected':''}>每天</option>
                    <option value="workweek" ${repeatType==='workweek'?'selected':''}>工作日</option>
                    <option value="holiday" ${repeatType==='holiday'?'selected':''}>节假日</option>
                    <option value="weekly" ${repeatType==='weekly'?'selected':''}>每周</option>
                    <option value="custom" ${repeatType==='custom'?'selected':''}>自定义</option>
                </select>
            </label>
        </div>
        <div id="modalRepeatDaysContainer" style="margin-bottom:12px;display:${repeatType==='custom'?'':'none'};">
            <div style="font-size:0.9rem;color:var(--text-light);margin-bottom:8px;">选择重复日期</div>
            <div id="modalRepeatDays" style="display:flex;flex-wrap:wrap;gap:6px;">
                ${weekDays.map(d => `<span class="tag-option ${repeatDays.includes(d.value)?'selected':''}" data-value="${d.value}">${d.label}</span>`).join('')}
            </div>
        </div>
        <div class="form-row">
            <label>开始日期
                <input type="date" id="modalStart" value="${task?.startDate||''}">
            </label>
            <label>结束日期
                <input type="date" id="modalEnd" value="${task?.endDate||''}">
            </label>
            <label>持续天数
                <input type="number" id="modalDuration" value="${task?.duration||''}" placeholder="自动">
            </label>
        </div>
        <div class="form-row">
            <label style="flex:1;">备注
                <textarea id="modalRemark" style="width:100%;">${task?.remark||''}</textarea>
            </label>
        </div>
        <div class="form-row">
            <div style="flex:1;">
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">
                    <div style="font-size:0.9rem;color:var(--text-light);">分配给角色</div>
                    <span class="select-all-btn" id="toggleAllRolesBtn">全选/取消</span>
                </div>
                <div id="modalRoleCheckboxes" style="display:flex;flex-wrap:wrap;gap:6px;"></div>
            </div>
        </div>
        <button class="btn btn-primary" id="saveTaskBtn">${task?'💾 更新任务':'✅ 保存任务'}</button>
    </div></div>`;
    document.getElementById('modalContainer').innerHTML = html;
    
    document.getElementById('modalRepeatType').addEventListener('change', function(){
        document.getElementById('modalRepeatDaysContainer').style.display = this.value === 'custom' ? '' : 'none';
    });
    
    document.querySelectorAll('#modalRepeatDays .tag-option').forEach(tag => {
        tag.addEventListener('click', function(){
            this.classList.toggle('selected');
        });
    });
    
    renderModalRoleTags(task?.assignedRoles||[]);
    document.getElementById('toggleAllRolesBtn').addEventListener('click', toggleAllModalRoles);
    document.getElementById('modalStart').addEventListener('change', ()=>autoCalcDates('modalStart','modalEnd','modalDuration'));
    document.getElementById('modalEnd').addEventListener('change', ()=>autoCalcDates('modalStart','modalEnd','modalDuration'));
    document.getElementById('modalDuration').addEventListener('input', ()=>autoCalcEndFromDuration('modalStart','modalDuration','modalEnd'));
    
    document.getElementById('saveTaskBtn').addEventListener('click', function(){
        saveTaskFromModal(editTaskId);
    });
}
function renderModalRoleTags(selectedIds = []) {
    const container = document.getElementById('modalRoleCheckboxes');
    if (!container) return;
    container.innerHTML = appRoles.map(r => {
        const isSelected = selectedIds.includes(r.id);
        return `<span class="role-tag ${isSelected ? 'selected' : ''}" data-roleid="${r.id}">${r.name} ${isSelected ? '✓' : '○'}</span>`;
    }).join('');
    container.querySelectorAll('.role-tag').forEach(tag => {
        tag.addEventListener('click', function() {
            this.classList.toggle('selected');
        });
    });
}
function toggleAllModalRoles(){
    const tags = document.querySelectorAll('#modalRoleCheckboxes .role-tag');
    const allSelected = [...tags].every(t => t.classList.contains('selected'));
    tags.forEach(t => {
        if(allSelected) t.classList.remove('selected');
        else t.classList.add('selected');
    });
}
function saveTaskFromModal(editId){
    const name = document.getElementById('modalTaskName').value.trim();
    const category = document.getElementById('modalTaskCategory').value;
    const typeName = document.getElementById('modalTaskTypeName').value.trim();
    if(!name||!category) return alert('名称和一级分类必填');
    
    let type = 'daily';
    if(typeName.includes('小周常') || typeName.includes('小常')) type = 'smallWeekly';
    else if(typeName.includes('大周常') || typeName.includes('大常')) type = 'bigWeekly';
    else if(typeName.includes('限时')) type = 'limited';
    else if(typeName) type = 'custom';
    
    const reward = parseFloat(document.getElementById('modalTaskReward').value)||0;
    const condition = parseInt(document.getElementById('modalTaskCondition').value)||1;
    const repeatType = document.getElementById('modalRepeatType').value;
    let repeatDays = [];
    if(repeatType === 'custom'){
        repeatDays = [...document.querySelectorAll('#modalRepeatDays .tag-option.selected')]
            .map(t => parseInt(t.dataset.value))
            .filter(Boolean);
    }
    let start = document.getElementById('modalStart').value;
    let end = document.getElementById('modalEnd').value;
    const dur = parseInt(document.getElementById('modalDuration').value)||0;
    const remark = document.getElementById('modalRemark').value.trim();
    if ((type === 'smallWeekly' || type === 'bigWeekly') && !start && !end) {
        start = '';
        end = '';
    }
    const selectedIds = [...document.querySelectorAll('#modalRoleCheckboxes .role-tag.selected')]
        .map(t => t.dataset.roleid)
        .filter(Boolean);
    if(editId){
        const task = appTasks.find(t=>t.id===editId);
        if(!task) return;
        Object.assign(task, {name,category,type,typeName,defaultReward:reward,condition,repeatType,repeatDays,startDate:start,endDate:end,duration:dur,remark,assignedRoles:selectedIds});
    } else {
        appTasks.push({
            id:genId(), name, category, type, typeName, defaultReward:reward,
            condition, repeatType, repeatDays, startDate:start, endDate:end, duration:dur, remark, assignedRoles:selectedIds
        });
    }
    saveAll();
    closeModal();
    if(document.getElementById('tab-record').classList.contains('active')) renderTaskView();
    if(document.getElementById('tab-home').classList.contains('active')) renderHome();
}

// ==================== 管理任务模态 ====================
function showManageTasksModal(){
    let html = `<div class="modal-overlay" onclick="closeModal()"><div class="modal" onclick="event.stopPropagation()"><h3>🗂️ 管理任务 <button class="close-btn" onclick="closeModal()">×</button></h3><div id="manageTaskListContainer"></div></div></div>`;
    document.getElementById('modalContainer').innerHTML = html;
    renderManageTaskList();
}
function renderManageTaskList(){
    const container = document.getElementById('manageTaskListContainer');
    if(!container) return;
    if(!appTasks.length){ container.innerHTML = '<p>暂无任务</p>'; return; }
    const grouped = {};
    appTasks.forEach(t => {
        if(!grouped[t.category]) grouped[t.category] = [];
        grouped[t.category].push(t);
    });
    let html = '<p style="font-size:0.85rem;color:var(--text-light);margin-bottom:8px;">💡 拖拽任务卡片可调整顺序</p>';
    for(const [cat, tasks] of Object.entries(grouped)){
        html += `<div style="margin-bottom:12px;"><strong>${cat}</strong><div class="task-sort-group" data-category="${cat}">`;
        tasks.forEach(t => {
            let d = {'daily':'日常','smallWeekly':'小周常','bigWeekly':'大周常','limited':'限时'}[t.type] || t.typeName || '自定义';
            html += `<div class="task-card" draggable="true" data-taskid="${t.id}">
                <span class="drag-handle" style="cursor:grab;margin-right:8px;">⋮⋮</span>
                <div class="task-info" style="flex:1;"><b>${t.name}</b> <small>(${d})</small><br><small>收益:${t.defaultReward}|条件:${t.condition}次</small></div>
                <div class="task-actions">
                    <button class="btn btn-sm edit-task-btn" data-taskid="${t.id}">编辑</button>
                    <button class="btn btn-sm btn-danger delete-task-btn" data-taskid="${t.id}">删除</button>
                </div>
            </div>`;
        });
        html += '</div></div>';
    }
    container.innerHTML = html;
    document.querySelectorAll('.task-card[draggable]').forEach(card => {
        card.addEventListener('dragstart', handleTaskDragStart);
        card.addEventListener('dragover', handleTaskDragOver);
        card.addEventListener('drop', handleTaskDrop);
        card.addEventListener('dragend', handleTaskDragEnd);
    });
    document.querySelectorAll('.edit-task-btn').forEach(btn => {
        btn.addEventListener('click', function(e){
            e.stopPropagation();
            const taskId = this.dataset.taskid;
            closeModal();
            showAddTaskModal(taskId);
        });
    });
    document.querySelectorAll('.delete-task-btn').forEach(btn => {
        btn.addEventListener('click', function(e){
            e.stopPropagation();
            const taskId = this.dataset.taskid;
            deleteTaskFromManage(taskId);
        });
    });
}
function deleteTaskFromManage(taskId){
    if(!confirm('确定删除吗？')) return;
    appTasks = appTasks.filter(t => t.id !== taskId);
    saveAll();
    renderManageTaskList();
    if(document.getElementById('tab-record').classList.contains('active')) renderTaskView();
    if(document.getElementById('tab-home').classList.contains('active')) renderHome();
}
let draggedTaskId = null;
let dragSource = null;
function handleTaskDragStart(e){
    draggedTaskId = this.dataset.taskid;
    dragSource = this.closest('.task-sort-group') ? 'manage' : 'record';
    this.style.opacity = '0.5';
    e.dataTransfer.effectAllowed = 'move';
}
function handleTaskDragOver(e){
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    this.style.borderTop = '2px solid var(--primary)';
}
function handleTaskDrop(e){
    e.preventDefault();
    this.style.borderTop = '';
    if(!draggedTaskId) return;
    const targetTaskId = this.dataset.taskid;
    if(draggedTaskId === targetTaskId) return;
    
    const draggedIndex = appTasks.findIndex(t => t.id === draggedTaskId);
    const targetIndex = appTasks.findIndex(t => t.id === targetTaskId);
    if(draggedIndex === -1 || targetIndex === -1) return;
    
    const [draggedTask] = appTasks.splice(draggedIndex, 1);
    appTasks.splice(targetIndex, 0, draggedTask);
    
    saveAll();
    renderManageTaskList();
    if(document.getElementById('tab-record').classList.contains('active')) renderTaskView();
}
function handleTaskDragEnd(e){
    this.style.opacity = '';
    document.querySelectorAll('.task-card[draggable]').forEach(card => {
        card.style.borderTop = '';
    });
    draggedTaskId = null;
    dragSource = null;
}
function autoCalcDates(s,e,d){
    const start = document.getElementById(s).value;
    const end = document.getElementById(e).value;
    if(start&&end) document.getElementById(d).value = Math.max(0, (new Date(end)-new Date(start))/86400000);
}
function autoCalcEndFromDuration(s,d,e){
    const start = document.getElementById(s).value;
    const dur = parseInt(document.getElementById(d).value);
    if(start && !isNaN(dur) && dur>=0){
        const dt = new Date(start);
        dt.setDate(dt.getDate()+dur);
        document.getElementById(e).value = dt.toISOString().split('T')[0];
    }
}
// ==================== 标签切换 ====================
document.getElementById('tabNav').addEventListener('click', e => {
    if(e.target.tagName !== 'BUTTON') return;
    document.querySelectorAll('#tabNav button').forEach(b=>b.classList.remove('active'));
    e.target.classList.add('active');
    document.querySelectorAll('.tab-content').forEach(c=>c.classList.remove('active'));
    const tabId = 'tab-' + e.target.dataset.tab;
    document.getElementById(tabId).classList.add('active');
    if(e.target.dataset.tab === 'home') renderHome();
    if(e.target.dataset.tab === 'record') { renderRecordRoleList(); renderTaskView(); }
    if(e.target.dataset.tab === 'analysis') { initAnalysisPage(); renderAnalysis(); }
    if(e.target.dataset.tab === 'showcase') { renderShowcaseGrid(); }
});

// ==================== 首页 ====================
function getPendingCount(roleId){
    const today = getToday();
    let count = 0;
    appTasks.forEach(t => {
        if(t.type==='daily' && isTaskVisibleForRole(t,roleId) && !appRecords[`${roleId}_${t.id}_${today}`]) count++;
    });
    return count;
}
function renderHome(){
    const today = getToday();
    let totalPending = 0, todayIncome = 0, todayExpense = 0, weekIncome = 0, weekExpense = 0;
    appRoles.forEach(r => {
        appTasks.forEach(t => {
            if(!isTaskVisibleForRole(t,r.id)) return;
            if(!isTaskActiveInDate(t, today)) return;
            if(t.type==='daily' || t.type==='smallWeekly'){
                if(!appRecords[`${r.id}_${t.id}_${today}`]) totalPending++;
            } else if(t.type==='bigWeekly'){
                if(!isTaskCDCompleted(r.id, t, today)) totalPending++;
            } else if(t.type==='limited'){
                const count = getLimitedCount(r.id, t.id);
                if(count < t.condition) totalPending++;
            }
        });
    });
    Object.entries(appRecords).forEach(([key, rec]) => {
        const parsed = parseRecordKey(key);
        if(!parsed) return;
        const {rid, tid, ds} = parsed;
        if(ds === today){
            todayIncome += rec.income || 0;
            (rec.expenses || []).forEach(ex => todayExpense += ex.amount || 0);
        }
    });
    const weekStart = new Date();
    const wsDay = weekStart.getDay();
    weekStart.setDate(weekStart.getDate() - (wsDay === 0 ? 6 : wsDay - 1));
    weekStart.setHours(0,0,0,0);
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekStart.getDate() + 6);
    weekEnd.setHours(23,59,59,999);
    Object.entries(appRecords).forEach(([key, rec]) => {
        const parsed = parseRecordKey(key);
        if(!parsed) return;
        const {rid, tid, ds} = parsed;
        const d = new Date(ds + 'T00:00:00');
        if(d < weekStart || d > weekEnd) return;
        weekIncome += rec.income || 0;
        weekExpense += (rec.expenses || []).reduce((s,e)=>s+(e.amount||0),0);
    });
    const limitedCountMap = {};
    Object.keys(appRecords).forEach(key => {
        const parsed = parseRecordKey(key);
        if(!parsed) return;
        const {rid, tid} = parsed;
        const task = appTasks.find(t => t.id === tid);
        if (task && task.type === 'limited') {
            const mapKey = `${rid}_${tid}`;
            limitedCountMap[mapKey] = (limitedCountMap[mapKey] || 0) + 1;
        }
    });
    let limitedTotal = 0, limitedCompleted = 0;
    appRoles.forEach(r => {
        appTasks.forEach(t => {
            if (t.type !== 'limited') return;
            if (!isTaskVisibleForRole(t, r.id)) return;
            limitedTotal++;
            const count = limitedCountMap[`${r.id}_${t.id}`] || 0;
            if (count >= t.condition) limitedCompleted++;
        });
    });
    document.getElementById('statCardsContainer').style.gridTemplateColumns = 'repeat(3, 1fr)';
    document.getElementById('statCardsContainer').innerHTML = `
        <div class="stat-card glass-card clickable" id="allRolesCard"><div class="stat-value">${appRoles.length}</div><div class="stat-label">我的角色</div></div>
        <div class="stat-card glass-card clickable" id="pendingStatCard"><div class="stat-value">${totalPending}</div><div class="stat-label">今日待完成</div></div>
        <div class="stat-card glass-card clickable" id="limitedStatCard"><div class="stat-value">${limitedCompleted}/${limitedTotal}</div><div class="stat-label">限时进度</div></div>
    `;
    document.getElementById('allRolesCard').addEventListener('click', () => showAllRolesModal());
    document.getElementById('pendingStatCard').addEventListener('click', showPendingRolesModal);
    document.getElementById('limitedStatCard').addEventListener('click', showLimitedProgressModal);
    document.getElementById('secondStatCardsContainer').innerHTML = `
        <div class="stat-card glass-card"><div class="stat-value">${formatCurrency(todayIncome)}</div><div class="stat-label">今日收入</div></div>
        <div class="stat-card glass-card"><div class="stat-value">${formatCurrency(todayExpense)}</div><div class="stat-label">今日支出</div></div>
        <div class="stat-card glass-card"><div class="stat-value">${formatCurrency(todayIncome - todayExpense)}</div><div class="stat-label">本日盈亏</div></div>
    `;
    setTimeout(() => {
        animateValue(document.querySelector('#allRolesCard .stat-value'), 0, appRoles.length, 600, false);
        animateValue(document.querySelector('#pendingStatCard .stat-value'), 0, totalPending, 800, false);
        const cards = document.querySelectorAll('#secondStatCardsContainer .stat-value');
        animateValue(cards[0], 0, todayIncome, 800, true);
        animateValue(cards[1], 0, todayExpense, 800, true);
        animateValue(cards[2], 0, (todayIncome - todayExpense), 800, true);
    }, 100);
    const recs = Object.entries(appRecords).sort((a,b)=>new Date(b[1].completedAt||0)-new Date(a[1].completedAt||0)).slice(0,6);
    let actHtml = '';
    if(recs.length === 0){
        actHtml = '<p style="color:var(--text-light);font-size:0.8rem;">暂无活动记录</p>';
    } else {
        recs.forEach(([key,rec]) => {
            const parsed = parseRecordKey(key);
            if(!parsed) return;
            const {rid, tid, ds} = parsed;
            const role = appRoles.find(r=>r.id===rid);
            const task = appTasks.find(t=>t.id===tid);
            if(role && task){
                const time = ds.slice(5);
                const net = rec.income - (rec.expenses||[]).reduce((s,e)=>s+e.amount,0);
                actHtml += `<div class="timeline-item"><span class="time">${time}</span><span class="desc">${role.name} · ${task.name}</span><span class="amount ${net>=0?'positive':'negative'}">${formatCurrency(net)}</span></div>`;
            }
        });
    }
    document.getElementById('recentActivityList').innerHTML = actHtml;
    const weekStats = {};
    appRoles.forEach(r => weekStats[r.id] = {name:r.name, income:0, expense:0});
    Object.entries(appRecords).forEach(([key,rec]) => {
        const parsed = parseRecordKey(key);
        if(!parsed) return;
        const {rid, tid, ds} = parsed;
        if(!weekStats[rid]) return;
        if(!rec.completedAt || new Date(rec.completedAt) < weekStart) return;
        weekStats[rid].income += rec.income||0;
        (rec.expenses||[]).forEach(ex => weekStats[rid].expense += ex.amount||0);
    });
    const sorted = Object.values(weekStats).sort((a,b)=>(b.income-b.expense)-(a.income-a.expense));
    const topEarn = sorted.slice(0,3);
    const topSpend = [...sorted].sort((a,b)=>b.expense-a.expense).slice(0,3);
    let repHtml = '<div style="display:flex;gap:12px;font-size:0.82rem;"><div style="flex:1;"><strong>💰 最会赚钱</strong><ul class="rank-list">';
    topEarn.forEach((s,i) => {
        const icons = ['🥇','🥈','🥉'];
        repHtml += `<li><span>${icons[i]} ${s.name}</span><span class="gold-text">${formatCurrency(s.income-s.expense)}</span></li>`;
    });
    repHtml += '</ul></div><div style="flex:1;"><strong>💸 最会花钱</strong><ul class="rank-list">';
    topSpend.forEach((s,i) => {
        const icons = ['🔥','💧','🍃'];
        repHtml += `<li><span>${icons[i]} ${s.name}</span><span style="color:var(--danger);">${formatCurrency(s.expense)}</span></li>`;
    });
    repHtml += '</ul></div></div>';
    document.getElementById('weekReport').innerHTML = repHtml;
    document.getElementById('quoteText').textContent = '—— ' + QUOTES[new Date().getDate() % QUOTES.length];
    document.getElementById('refreshQuoteBtn').addEventListener('click', function(){
        const randomQuote = QUOTES[Math.floor(Math.random() * QUOTES.length)];
        document.getElementById('quoteText').textContent = '—— ' + randomQuote;
    });
}
document.getElementById('fortuneBtn').addEventListener('click', function(){
    const res = FORTUNES[Math.floor(Math.random()*FORTUNES.length)];
    const el = document.getElementById('fortuneResult');
    el.classList.add('ing');
    let color = 'var(--text)';
    if (res.text.includes('大吉')) color = 'var(--gold)';
    else if (res.text.includes('中吉') || res.text.includes('小吉')) color = 'var(--primary)';
    else if (res.text.includes('凶')) color = 'var(--danger)';
    el.innerHTML = `<span class="divine">${res.icon}</span><span style="color:${color}; font-size:1rem;">${res.text}</span><br><small style="color:var(--text-light);">${res.desc}</small>`;
    setTimeout(()=>el.classList.remove('ing'), 600);
});
function animateValue(element, start, end, duration, isCurrency) {
    const range = end - start;
    const increment = range / (duration / 16);
    let current = start;
    const timer = setInterval(() => {
        current += increment;
        if ((increment > 0 && current >= end) || (increment < 0 && current <= end)) {
            current = end;
            clearInterval(timer);
        }
        element.textContent = isCurrency ? formatCurrency(Math.round(current)) : Math.round(current);
    }, 16);
}
function showAllRolesModal() {
    if (appRoles.length === 0) {
        alert('暂无角色，请先添加角色');
        return;
    }
    const today = getToday();
    let html = `<div class="modal-overlay" onclick="closeModal()">
        <div class="modal pending-modal" onclick="event.stopPropagation()">
            <h3>👥 全部角色 <button class="close-btn" onclick="closeModal()">×</button></h3>
            <div class="role-cards" style="margin-bottom:0;">`;
    appRoles.forEach(r => {
        const pending = getPendingCount(r.id);
        let completed = 0;
        appTasks.forEach(t => {
            if (t.type === 'daily' && isTaskVisibleForRole(t, r.id) && appRecords[`${r.id}_${t.id}_${today}`]) {
                completed++;
            }
        });
        html += `
            <div class="role-card" style="cursor:pointer;">
                <div style="display:flex; gap:8px; align-items:center;">
                    <div class="completed-count">${completed}</div>
                    <div class="pending-count ${pending===0?'zero':''}">${pending}</div>
                </div>
                <div class="role-name">${r.name}</div>
                <div class="role-server">${r.server}</div>
                <div class="role-meta"><span>${r.faction}</span><span>${r.bodyType}</span></div>
            </div>`;
    });
    html += `</div>
            <p style="text-align:center;margin-top:12px;font-size:0.8rem;color:var(--text-light);">红色=未完成 | 绿色=已完成 | 点击角色卡片跳转至任务记录页</p>
        </div></div>`;
    document.getElementById('modalContainer').innerHTML = html;
    document.querySelectorAll('.pending-modal .role-card').forEach((card, index) => {
        card.addEventListener('click', function() {
            const role = appRoles[index];
            closeModal();
            document.querySelector('[data-tab="record"]').click();
            recordSelectedRoles.clear();
            recordSelectedRoles.add(role.id);
            renderRecordRoleList();
            renderTaskView();
        });
    });
}
function showPendingRolesModal() {
    const today = getToday();
    const pendingRoles = appRoles.filter(r => {
        return appTasks.some(t => {
            if (t.type !== 'daily') return false;
            if (!isTaskVisibleForRole(t, r.id)) return false;
            return !appRecords[`${r.id}_${t.id}_${today}`];
        });
    });
    if (pendingRoles.length === 0) {
        alert('🎉 所有角色今日任务已全部完成！');
        return;
    }
    let html = `<div class="modal-overlay" onclick="closeModal()">
        <div class="modal pending-modal" onclick="event.stopPropagation()">
            <h3>📋 今日待完成 <button class="close-btn" onclick="closeModal()">×</button></h3>
            <div class="role-cards" style="margin-bottom:0;">`;
    pendingRoles.forEach(r => {
        const pending = getPendingCount(r.id);
        html += `
            <div class="role-card">
                <div class="pending-count ${pending===0?'zero':''}">${pending}</div>
                <div class="role-name">${r.name}</div>
                <div class="role-server">${r.server}</div>
                <div class="role-meta"><span>${r.faction}</span><span>${r.bodyType}</span></div>
            </div>`;
    });
    html += `</div>
            <p style="text-align:center;margin-top:12px;font-size:0.8rem;color:var(--text-light);">点击角色卡片可跳转至任务记录页查看详情</p>
        </div></div>`;
    document.getElementById('modalContainer').innerHTML = html;
    document.querySelectorAll('.pending-modal .role-card').forEach((card, index) => {
        card.addEventListener('click', function() {
            const role = pendingRoles[index];
            closeModal();
            document.querySelector('[data-tab="record"]').click();
            recordSelectedRoles.clear();
            recordSelectedRoles.add(role.id);
            renderRecordRoleList();
            renderTaskView();
        });
        card.style.cursor = 'pointer';
    });
}
function showLimitedProgressModal() {
    const limitedTasks = appTasks.filter(t => t.type === 'limited');
    if (limitedTasks.length === 0) {
        alert('暂无限时任务');
        return;
    }
    let html = `<div class="modal-overlay" onclick="closeModal(); renderHome();">
        <div class="modal pending-modal" onclick="event.stopPropagation()" style="max-width:700px;">
            <h3>📊 限时任务进度 <button class="close-btn" onclick="closeModal(); renderHome();">×</button></h3>
            <div style="overflow-x:auto;">
                <table class="task-table" style="min-width:500px;">
                    <thead><tr><th>任务 \\ 角色</th>`;
    appRoles.forEach(r => { html += `<th>${r.name}</th>`; });
    html += '</thead><tbody>';
    limitedTasks.forEach(t => {
        html += `<tr><td><strong>${t.name}</strong><br><small>目标:${t.condition}次</small></td>`;
        appRoles.forEach(r => {
            if (!isTaskVisibleForRole(t, r.id)) {
                html += '<td>-</td>';
                return;
            }
            let count = 0;
            Object.keys(appRecords).forEach(key => {
                const parts = key.split('_');
                if (parts.length >= 3) {
                    const tid = parts[parts.length - 2];
                    const rid = parts.slice(0, parts.length - 2).join('_');
                    if (rid === r.id && tid === t.id) count++;
                }
            });
            const pct = Math.min(100, Math.round((count / t.condition) * 100));
            const done = count >= t.condition;
            html += `<td style="text-align:center;">
                <div style="font-weight:700;color:${done ? 'var(--success)' : 'var(--primary)'};">${count}/${t.condition}</div>
                <div style="background:var(--border);border-radius:4px;height:6px;margin-top:4px;">
                    <div style="background:${done ? 'var(--success)' : 'var(--primary)'};border-radius:4px;height:100%;width:${pct}%;"></div>
                </div>
             </td>`;
        });
        html += '</tr>';
    });
    html += '</tbody></table></div></div></div>';
    document.getElementById('modalContainer').innerHTML = html;
}
// ==================== 任务记录 ====================
let recordSelectedRoles = new Set();
let currentView = 'day';
let currentRecordDate = getToday();

function renderRecordRoleList(filteredRoles) {
    const source = filteredRoles || getFilteredRoles();
    renderTagSelect('recordRoleTags', source, [...recordSelectedRoles], 'onRecordRoleToggle');
}
function getFilteredRoles() {
    const bodyFilter = document.getElementById('roleBodyFilter').value;
    const factionFilter = document.getElementById('roleFactionFilter').value;
    return appRoles.filter(r => {
        if(bodyFilter && r.bodyType !== bodyFilter) return false;
        if(factionFilter && r.faction !== factionFilter) return false;
        return true;
    });
}
function onRoleFilterChange() {
    recordSelectedRoles = new Set([...recordSelectedRoles].filter(rid => {
        const role = appRoles.find(r => r.id === rid);
        if(!role) return false;
        const bodyFilter = document.getElementById('roleBodyFilter').value;
        const factionFilter = document.getElementById('roleFactionFilter').value;
        if(bodyFilter && role.bodyType !== bodyFilter) return false;
        if(factionFilter && role.faction !== factionFilter) return false;
        return true;
    }));
    renderRecordRoleList();
    renderTaskView();
}
function onRecordRoleToggle(ids) {
    recordSelectedRoles = new Set(ids);
    renderTaskView();
}
document.getElementById('roleFilterBtn').addEventListener('click', function(){
    const filteredRoles = getFilteredRoles();
    const filteredIds = new Set(filteredRoles.map(r => r.id));
    const allFilteredSelected = filteredRoles.every(r => recordSelectedRoles.has(r.id));
    if(allFilteredSelected){
        recordSelectedRoles = new Set([...recordSelectedRoles].filter(rid => !filteredIds.has(rid)));
    } else {
        filteredRoles.forEach(r => recordSelectedRoles.add(r.id));
    }
    renderRecordRoleList();
    renderTaskView();
});
document.getElementById('roleClearFilterBtn').addEventListener('click', function(){
    document.getElementById('roleBodyFilter').value = '';
    document.getElementById('roleFactionFilter').value = '';
    renderRecordRoleList();
});
document.getElementById('roleBodyFilter').addEventListener('change', onRoleFilterChange);
document.getElementById('roleFactionFilter').addEventListener('change', onRoleFilterChange);
document.getElementById('recordDatePicker').addEventListener('change', function(){
    const val = this.value;
    if(!val) return;
    if(currentView === 'day'){
        currentRecordDate = val;
    } else if(currentView === 'week'){
        currentRecordDate = val;
    } else if(currentView === 'month'){
        if(this.type === 'month'){
            const [y,m] = val.split('-');
            currentRecordDate = y + '-' + m.padStart(2,'0') + '-01';
        } else {
            const d = new Date(val+'T00:00:00');
            currentRecordDate = d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-01';
        }
    }
    renderTaskView();
});
document.querySelector('.view-toggle').addEventListener('click', e => {
    if(e.target.tagName !== 'BUTTON') return;
    document.querySelectorAll('.view-toggle button').forEach(b=>b.classList.remove('active'));
    e.target.classList.add('active');
    currentView = e.target.dataset.view;
    const picker = document.getElementById('recordDatePicker');
    if(currentView === 'month'){
        try { picker.type = 'month'; } catch(e){}
    } else {
        try { picker.type = 'date'; } catch(e){}
    }
    renderTaskView();
});
document.getElementById('filterCategory').addEventListener('change', renderTaskView);
document.getElementById('filterType').addEventListener('change', renderTaskView);
document.getElementById('filterStatus').addEventListener('change', renderTaskView);
function updateFilterOptions(){
    document.getElementById('filterCategory').innerHTML = '<option value="all">全部分类</option>' +
        [...new Set(appTasks.map(t=>t.category).filter(Boolean))].map(c=>`<option value="${c}">${c}</option>`).join('');
    document.getElementById('filterType').innerHTML = '<option value="all">全部类型</option><option value="daily">日常</option><option value="smallWeekly">小周常</option><option value="bigWeekly">大周常</option><option value="limited">限时</option><option value="custom">自定义</option>';
    document.getElementById('filterStatus').innerHTML = '<option value="all">全部状态</option><option value="done">已完成</option><option value="undone">未完成</option>';
}
function updatePeriodLabel(){
    const picker = document.getElementById('recordDatePicker');
    if(currentView === 'day'){
        try { picker.type = 'date'; } catch(e){}
        picker.value = currentRecordDate;
    } else if(currentView === 'week'){
        try { picker.type = 'date'; } catch(e){}
        picker.value = currentRecordDate;
    } else if(currentView === 'month'){
        try { picker.type = 'month'; } catch(e){}
        const d = new Date(currentRecordDate + 'T00:00:00');
        const ym = d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0');
        picker.value = ym;
    }
}
function renderTaskView(){
    const roles = appRoles.filter(r => recordSelectedRoles.has(r.id));
    if(!roles.length){
        document.getElementById('taskViewContent').innerHTML = '<p style="color:var(--text-light);">请选择角色</p>';
        updatePeriodLabel();
        return;
    }
    const cat = document.getElementById('filterCategory').value;
    const type = document.getElementById('filterType').value;
    const status = document.getElementById('filterStatus').value;
    let tasks = appTasks.filter(t => 
        (cat==='all' || t.category===cat) && 
        (type==='all' || (type==='custom'?t.type==='custom':t.type===type))
    );
    if(currentView === 'day') {
        tasks = tasks.filter(t => isTaskActiveInDate(t, currentRecordDate));
    }
    updatePeriodLabel();
    if(currentView === 'day') renderDayView(roles, tasks, status);
    else if(currentView === 'week') renderWeekView(roles, tasks, status);
    else renderMonthViewSimple(roles, tasks, status);
}
function onTaskCellClick(roleId, taskId, dateStr){
    const recordKey = `${roleId}_${taskId}_${dateStr}`;
    const task = appTasks.find(t=>t.id===taskId);
    const role = appRoles.find(r=>r.id===roleId);
    if(!task||!role) return;
    if(appRecords[recordKey]){
        if(task.type === 'bigWeekly'){
            const d = new Date(dateStr + 'T00:00:00'); d.setHours(0,0,0,0);
            const dow = d.getDay();
            const off = dow===0 ? -6 : 1-dow;
            const mon = new Date(d); mon.setDate(d.getDate()+off);
            const weekDates = [];
            for(let i=0;i<7;i++){ const dd=new Date(mon); dd.setDate(mon.getDate()+i); weekDates.push(dd.getFullYear()+'-'+String(dd.getMonth()+1).padStart(2,'0')+'-'+String(dd.getDate()).padStart(2,'0')); }
            if(confirm(`确定将「${role.name}」的「${task.name}」所在周期内的完成记录全部取消吗？`)){
                weekDates.forEach(ds => {
                    const key = `${roleId}_${taskId}_${ds}`;
                    if(appRecords[key]) delete appRecords[key];
                });
                saveAll(); renderTaskView(); renderHome();
            }
        } else {
            if(confirm(`确定将「${role.name}」的「${task.name}」标记为未完成吗？`)){
                delete appRecords[recordKey];
                saveAll();
                renderTaskView();
                renderHome();
            }
        }
    } else {
        showCompleteModal(role, task, dateStr);
    }
}
function showCompleteModal(role, task, dateStr){
    let modalHTML = `<div class="modal-overlay"><div class="modal"><button class="close-btn" onclick="closeModal()">×</button><h3>✅ 完成任务</h3>
        <div style="background:var(--task-card-bg);padding:12px;border-radius:8px;margin-bottom:16px;">
            <strong>${role.name}</strong> · ${task.name}<br><small>${dateStr}</small>
        </div>
        <label style="display:block;margin-bottom:12px;">收入 (${currencyData.unit})
            <input type="number" id="incomeInput" value="${task.defaultReward||0}" step="0.01" style="width:100%;padding:8px;border:1px solid var(--border);border-radius:6px;background:var(--input-bg);color:var(--text);">
        </label>
        <div style="margin-bottom:8px;"><strong>支出明细</strong></div>
        <div id="expenseList"></div>
        <button class="btn btn-sm" id="addExpenseBtn">+ 添加支出</button>
        <div style="text-align:right;margin-top:16px;">
            <button class="btn" style="background:#b2bec3;color:#fff;" onclick="closeModal()">取消</button>
            <button class="btn btn-primary" id="confirmCompleteBtn">确认完成</button>
        </div>
    </div></div>`;
    document.getElementById('modalContainer').innerHTML = modalHTML;
    document.getElementById('addExpenseBtn').addEventListener('click', addExpenseRow);
    document.getElementById('confirmCompleteBtn').addEventListener('click', function(){
        confirmComplete(role.id, task.id, dateStr);
    });
}
function addExpenseRow(){
    const div = document.getElementById('expenseList');
    const row = document.createElement('div');
    row.className = 'expense-row';
    row.innerHTML = `<input type="number" placeholder="金额" class="expense-amount" step="0.01"><input type="text" placeholder="备注" class="expense-note"><button class="btn btn-sm btn-danger" onclick="this.parentElement.remove()">删除</button>`;
    div.appendChild(row);
}
function confirmComplete(roleId, taskId, dateStr){
    const income = parseFloat(document.getElementById('incomeInput').value) || 0;
    const rows = document.querySelectorAll('#expenseList .expense-row');
    let expenses = [];
    rows.forEach(r => {
        const amt = parseFloat(r.querySelector('.expense-amount').value) || 0;
        const note = r.querySelector('.expense-note').value.trim() || '无备注';
        if(amt > 0) expenses.push({amount:amt, note});
    });
    const task = appTasks.find(t=>t.id===taskId);
    const nowIso = new Date().toISOString();
    const recordValue = { completed: true, income: income, expenses: expenses, completedAt: nowIso };
    appRecords[`${roleId}_${taskId}_${dateStr}`] = recordValue;
    saveAll();
    closeModal();
    renderTaskView();
    renderHome();
}
function renderDayView(roles, tasks, status){
    const todayStr = getToday();
    let html = '<p style="font-size:0.85rem;color:var(--text-light);margin-bottom:8px;">💡 拖拽表头可调整任务顺序</p>';
    html += '<table class="task-table"><thead><tr><th>角色</th>';
    tasks.forEach(t => html += `<th class="draggable-header" draggable="true" data-taskid="${t.id}" style="cursor:grab;"><span style="margin-right:4px;">⋮⋮</span>${t.name}</th>`);
    html += '</tr></thead><tbody>';
    roles.forEach(r => {
        html += `<tr><td><strong>${r.name}</strong></td>`;
        tasks.forEach(t => {
            if(!isTaskVisibleForRole(t, r.id)){
                if(t.assignedRoles && t.assignedRoles.length>0) html += '<td class="unassigned">未分配</td>';
                else html += '<td>-</td>';
                return;
            }
            const dateStr = currentRecordDate;
            const isPast = dateStr < todayStr;
            const done = appRecords[`${r.id}_${t.id}_${dateStr}`];
            const cdDone = (t.type === 'bigWeekly') ? isTaskCDCompleted(r.id, t, dateStr) : false;
            const isActive = isTaskActiveInDate(t, dateStr);
            if(!isActive){ html += (t.type === 'smallWeekly' ? '<td></td>' : '<td>-</td>'); return; }
            if(t.type === 'limited' && isActive){
                if(getLimitedCount(r.id, t.id) >= t.condition){
                    html += '<td>-</td>';
                    return;
                }
            }
            if(status==='all' || (status==='done' && (done||cdDone)) || (status==='undone' && !done && !cdDone)){
                if(done || cdDone){
                    html += `<td class="done" data-roleid="${r.id}" data-taskid="${t.id}" data-date="${dateStr}">✅</td>`;
                } else if(isPast && !done && !cdDone){
                    html += `<td class="expired" data-roleid="${r.id}" data-taskid="${t.id}" data-date="${dateStr}">✗</td>`;
                } else {
                    html += `<td class="undone" data-roleid="${r.id}" data-taskid="${t.id}" data-date="${dateStr}">·</td>`;
                }
            } else {
                html += '<td></td>';
            }
        });
        html += '</tr>';
    });
    html += '</tbody></table>';
    document.getElementById('taskViewContent').innerHTML = html;
    document.querySelectorAll('.draggable-header').forEach(header => {
        header.addEventListener('dragstart', handleTaskDragStart);
        header.addEventListener('dragover', handleTaskDragOver);
        header.addEventListener('drop', handleTaskDrop);
        header.addEventListener('dragend', handleTaskDragEnd);
    });
    document.querySelectorAll('.done, .undone, .expired').forEach(cell => {
        cell.addEventListener('click', function(){
            const roleId = this.dataset.roleid;
            const taskId = this.dataset.taskid;
            const date = this.dataset.date;
            onTaskCellClick(roleId, taskId, date);
        });
    });
}
function renderWeekView(roles, tasks, status){
    const now = new Date(currentRecordDate + 'T00:00:00');
    now.setHours(0,0,0,0);
    const dow = now.getDay();
    const off = dow===0 ? -6 : 1-dow;
    const mon = new Date(now);
    mon.setDate(now.getDate()+off);
    const weekDates = [], days = ['周一','周二','周三','周四','周五','周六','周日'];
    for(let i=0; i<7; i++){
        const d = new Date(mon);
        d.setDate(mon.getDate()+i);
        weekDates.push(d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'));
    }
    const todayStr = getToday();
    let html = '<table class="task-table"><thead><tr><th>任务</th>';
    days.forEach((d,i) => html += `<th>${d}<br><span style="font-size:0.65rem;">${weekDates[i].slice(5)}</span></th>`);
    html += '</tr></thead><tbody>';
    tasks.forEach(t => {
        html += `<tr><td><strong>${t.name}</strong></td>`;
        if(t.type === 'bigWeekly'){
            let doneCount = 0, total = 0;
            roles.forEach(r => {
                if(!isTaskVisibleForRole(t, r.id)) return;
                total++;
                for(let i=0; i<7; i++){
                    if(appRecords[`${r.id}_${t.id}_${weekDates[i]}`]){ doneCount++; break; }
                }
            });
            if(total === 0){
                if(t.assignedRoles && t.assignedRoles.length>0) html += '<td colspan="7" class="unassigned">未分配</td>';
                else html += '<td colspan="7"></td>';
            }
            else if(total === 1){
                html += `<td colspan="7" class="count-cell" data-roleid="${roles[0].id}" data-taskid="${t.id}" data-date="${weekDates[0]}">${doneCount?'✅':'·'}</td>`;
            } else {
                html += `<td colspan="7" class="count-cell" data-taskid="${t.id}" data-date="${weekDates[0]}">${doneCount}/${total}</td>`;
            }
        } else {
            weekDates.forEach(ds => {
                if(!isTaskActiveInDate(t, ds)){ html += (t.type === 'smallWeekly' ? '<td></td>' : '<td>-</td>'); return; }
                let doneCount = 0, total = 0;
                roles.forEach(r => {
                    if(isTaskVisibleForRole(t, r.id)){
                        total++;
                        if(t.type === 'limited' && getLimitedCount(r.id, t.id) >= t.condition){
                            doneCount++;
                        } else if(appRecords[`${r.id}_${t.id}_${ds}`]){
                            doneCount++;
                        }
                    }
                });
                if(total === 0){ html += (t.type === 'smallWeekly' ? '<td></td>' : '<td>-</td>'); return; }
                const undone = total - doneCount;
                const isPast = ds < todayStr;
                if(total === 1){
                    if(doneCount) html += `<td class="done count-cell" data-roleid="${roles[0].id}" data-taskid="${t.id}" data-date="${ds}">✅</td>`;
                    else if(isPast) html += `<td class="expired count-cell" data-roleid="${roles[0].id}" data-taskid="${t.id}" data-date="${ds}">✗</td>`;
                    else html += `<td class="undone count-cell" data-roleid="${roles[0].id}" data-taskid="${t.id}" data-date="${ds}">·</td>`;
                } else {
                    html += `<td class="count-cell" data-taskid="${t.id}" data-date="${ds}">${doneCount}/${undone}</td>`;
                }
            });
        }
        html += '</tr>';
    });
    html += '</tbody></table>';
    document.getElementById('taskViewContent').innerHTML = html;
    document.querySelectorAll('.count-cell').forEach(cell => {
        cell.addEventListener('click', function(){
            const taskId = this.dataset.taskid;
            const date = this.dataset.date;
            const roleId = this.dataset.roleid;
            if(roleId){
                onTaskCellClick(roleId, taskId, date);
            } else {
                showWeekDetail(taskId, date);
            }
        });
    });
}
function renderMonthViewSimple(roles, tasks, status){
    const now = new Date(currentRecordDate + 'T00:00:00');
    now.setHours(0,0,0,0);
    const y = now.getFullYear(), m = now.getMonth();
    const dim = new Date(y, m+1, 0).getDate();
    const fday = new Date(y, m, 1).getDay();
    let html = `<h3 style="text-align:center;">${y}年${m+1}月</h3><div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px;text-align:center;">`;
    ['日','一','二','三','四','五','六'].forEach(d => html += `<div style="font-weight:700;font-size:0.8rem;color:var(--text-light);">${d}</div>`);
    for(let i=0; i<fday; i++) html += '<div></div>';
    for(let d=1; d<=dim; d++){
        const ds = `${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
        let total = 0, done = 0;
        roles.forEach(r => tasks.forEach(t => {
            if(!isTaskActiveInDate(t, ds)) return;
            if(!isTaskVisibleForRole(t, r.id)) return;
            total++;
            if(t.type === 'bigWeekly'){
                if(isTaskCDCompleted(r.id, t, ds)) done++;
            } else if(t.type === 'limited'){
                if(getLimitedCount(r.id, t.id) >= t.condition) done++;
                else if(appRecords[`${r.id}_${t.id}_${ds}`]) done++;
            } else {
                if(appRecords[`${r.id}_${t.id}_${ds}`]) done++;
            }
        }));
        const countText = total ? `${done}/${total}` : '';
        const color = total ? ((total - done) > 0 ? 'var(--danger)' : 'var(--success)') : 'var(--text-light)';
        html += `<div style="background:var(--card-bg);border-radius:8px;padding:6px;min-height:55px;cursor:pointer;border:1px solid var(--border);font-size:0.8rem;" data-date="${ds}">
            <div style="font-weight:700;">${d}</div>
            <div style="font-size:0.65rem;color:${color};">${countText}</div>
        </div>`;
    }
    html += '</div>';
    document.getElementById('taskViewContent').innerHTML = html;
    document.querySelectorAll('[data-date]').forEach(day => {
        day.addEventListener('click', function(){ goToDay(this.dataset.date); });
    });
}
function showWeekDetail(taskId, dateStr){
    const task = appTasks.find(t=>t.id===taskId);
    const roles = appRoles.filter(r => recordSelectedRoles.has(r.id) && isTaskVisibleForRole(task, r.id));
    let done = [], undone = [];
    roles.forEach(r => {
        if(task.type === 'bigWeekly'){
            if(isTaskCDCompleted(r.id, task, dateStr)) done.push(r.name);
            else undone.push(r.name);
        } else {
            if(appRecords[`${r.id}_${taskId}_${dateStr}`]) done.push(r.name);
            else undone.push(r.name);
        }
    });
    document.getElementById('modalContainer').innerHTML = `
        <div class="modal-overlay" onclick="closeModal()"><div class="modal"><button class="close-btn" onclick="closeModal()">×</button>
            <h3>${task?.name||''} - ${dateStr}</h3>
            <p>✅ 已完成：${done.join('、')||'无'}</p>
            <p>❌ 未完成：${undone.join('、')||'无'}</p>
        </div></div>`;
}
function goToDay(ds){
    currentRecordDate = ds;
    document.getElementById('recordDatePicker').value = ds;
    currentView = 'day';
    document.querySelectorAll('.view-toggle button').forEach(b=>b.classList.remove('active'));
    document.querySelector('[data-view="day"]').classList.add('active');
    document.getElementById('recordDatePicker').style.display = '';
    renderTaskView();
}

// ==================== 盈亏分析 ====================
let analysisCharts = [];
let currentChartType = 'bar';
let currentDimension = 'net';
let analysisSelectedRoleIds = [];
function getFactionAbbr(faction) {
    const map = {'万花':'花','七秀':'秀','少林':'僧','天策':'策','纯阳':'道','藏剑':'剑','五毒':'毒','唐门':'唐','明教':'明','丐帮':'丐','苍云':'苍','长歌':'歌','霸刀':'刀','蓬莱':'蓬','凌雪阁':'凌','衍天宗':'衍','药宗':'药','刀宗':'刀','万灵':'灵','段氏':'段'};
    return map[faction] || faction.charAt(0);
}
function renderAnalysisRoleCards(){
    const container = document.getElementById('analysisRoleCards');
    if(!container) return;
    const selectedIds = getAnalysisSelectedIds();
    const total = appRoles.length;
    const selectedCount = selectedIds.length;
    const html = `
        <div class="analysis-role-inline">
            <button class="btn btn-sm" id="openAnalysisRolePicker">选择角色</button>
            <div class="role-count">已选 ${selectedCount} / 共 ${total} 人</div>
        </div>`;
    container.innerHTML = html;
    document.getElementById('openAnalysisRolePicker').addEventListener('click', showAnalysisRolePicker);
}
function getAnalysisSelectedIds(){
    if(Array.isArray(analysisSelectedRoleIds) && analysisSelectedRoleIds.length>0) return analysisSelectedRoleIds;
    const cards = document.querySelectorAll('#analysisRoleCards .role-card.selected');
    return [...cards].map(c => c.dataset.roleid);
}
function renderAnalysis(){
    analysisCharts.forEach(c => c.destroy());
    analysisCharts = [];
    const selectedIds = getAnalysisSelectedIds();
    const {start, end} = getAnalysisRange();
    const selectedRoles = appRoles.filter(r => selectedIds.includes(r.id));
    if(!selectedRoles.length){
        document.getElementById('analysisSummary').innerHTML = '';
        document.getElementById('analysisCharts').innerHTML = '<p style="text-align:center;color:var(--text-light);">请选择至少一个角色</p>';
        return;
    }
    let totalIncome = 0, totalExpense = 0;
    const roleStats = {};
    selectedRoles.forEach(r => roleStats[r.id] = {name:r.name, income:0, expense:0});
    const dailyMap = {}, roleDailyMap = {}, taskIncome = {}, taskExpense = {}, taskNet = {};
    Object.entries(appRecords).forEach(([key, rec]) => {
        const parsed = parseRecordKey(key);
        if(!parsed) return;
        const {rid, tid, ds} = parsed;
        if(!roleStats[rid]) return;
        const d = new Date(ds + 'T00:00:00');
        if(d < start || d > end) return;
        const task = appTasks.find(t => t.id === tid);
        if (!task) return; // 任务已被删除，跳过该记录
        const inc = rec.income || 0;
        const exp = (rec.expenses || []).reduce((s, e) => s + e.amount, 0);
        roleStats[rid].income += inc;
        roleStats[rid].expense += exp;
        totalIncome += inc;
        totalExpense += exp;
        if(!dailyMap[ds]) dailyMap[ds] = {income:0, expense:0};
        dailyMap[ds].income += inc;
        dailyMap[ds].expense += exp;
        if(!roleDailyMap[rid]) roleDailyMap[rid] = {};
        if(!roleDailyMap[rid][ds]) roleDailyMap[rid][ds] = {income:0, expense:0};
        roleDailyMap[rid][ds].income += inc;
        roleDailyMap[rid][ds].expense += exp;
        if(selectedRoles.length === 1 && rid === selectedRoles[0].id){
            const name = task ? task.name : '其他';
            taskIncome[name] = (taskIncome[name] || 0) + inc;
            const expForTask = (rec.expenses || []).reduce((s,e)=>s+e.amount,0);
            taskExpense[name] = (taskExpense[name] || 0) + expForTask;
            taskNet[name] = (taskNet[name] || 0) + (inc - expForTask);
        }
    });
    document.getElementById('analysisSummary').innerHTML = `
        <div class="stat-card glass-card"><div class="stat-value">${formatCurrency(totalIncome)}</div><div class="stat-label">总收入</div></div>
        <div class="stat-card glass-card"><div class="stat-value">${formatCurrency(totalExpense)}</div><div class="stat-label">总支出</div></div>
        <div class="stat-card glass-card"><div class="stat-value" style="color:${totalIncome-totalExpense>=0?'var(--success)':'var(--danger)'}">${formatCurrency(totalIncome-totalExpense)}</div><div class="stat-label">净盈亏</div></div>
    `;
    const chartsDiv = document.getElementById('analysisCharts');
    const dates = Object.keys(dailyMap).sort();
    const names = selectedRoles.map(r => r.name);
    let chartHTML = '';
    if(selectedRoles.length === 1){
        if(currentChartType === 'bar') currentChartType = 'line';
        const singleRole = selectedRoles[0];
        chartHTML += `<div class="chart-card-wrapper glass-card" style="margin-bottom:16px;">
            <div class="chart-switch-bar">
                <button class="switch-btn ${currentChartType==='line'?'active':''}" id="btn-line">折线图</button>
                <button class="switch-btn ${currentChartType==='pie'?'active':''}" id="btn-pie">饼状图</button>
            </div>
            <canvas id="singleChart"></canvas>
        </div>`;
        chartsDiv.innerHTML = chartHTML;
        (function(){
            const wrapper = chartsDiv.querySelector('.chart-card-wrapper');
            if(wrapper && !wrapper.querySelector('.dimension-bar')){
                const db = document.createElement('div'); db.className='dimension-bar';
                db.innerHTML = `
                    <button class="dimension-btn ${currentDimension==='net'?'active':''}" id="btn-net">净盈亏</button>
                    <button class="dimension-btn ${currentDimension==='income'?'active':''}" id="btn-income">收入</button>
                    <button class="dimension-btn ${currentDimension==='expense'?'active':''}" id="btn-expense">支出</button>`;
                wrapper.insertBefore(db, wrapper.firstChild);
            }
            const bLine = document.getElementById('btn-line'); if(bLine) bLine.addEventListener('click', ()=> switchChartType('line'));
            const bPie = document.getElementById('btn-pie'); if(bPie) bPie.addEventListener('click', ()=> switchChartType('pie'));
            const bNet = document.getElementById('btn-net'); if(bNet) bNet.addEventListener('click', ()=> switchDimension('net'));
            const bInc = document.getElementById('btn-income'); if(bInc) bInc.addEventListener('click', ()=> switchDimension('income'));
            const bExp = document.getElementById('btn-expense'); if(bExp) bExp.addEventListener('click', ()=> switchDimension('expense'));
        })();
        if(currentChartType === 'line'){
            const ctx = document.getElementById('singleChart').getContext('2d');
            analysisCharts.push(new Chart(ctx, {
                type:'line', data:{ labels:dates, datasets:[
                    {label:'收入', data:dates.map(d=>dailyMap[d].income), borderColor:'#00b894', tension:0.3},
                    {label:'支出', data:dates.map(d=>dailyMap[d].expense), borderColor:'#e17055', tension:0.3}
                ]},
                options:{plugins:{title:{display:true,text:`${singleRole.name} 收支走向`}}}
            }));
        } else {
            const ctx = document.getElementById('singleChart').getContext('2d');
            analysisCharts.push(new Chart(ctx, {
                type:'pie', data:{labels:Object.keys(taskIncome), datasets:[{data:Object.values(taskIncome)}]},
                options:{plugins:{title:{display:true,text:'收入来源'}}}
            }));
        }
    } else {
        chartHTML += `<div class="chart-card-wrapper glass-card" style="margin-bottom:16px;">
            <div class="dimension-bar">
                <button class="dimension-btn ${currentDimension==='net'?'active':''}" id="btn-net">净盈亏</button>
                <button class="dimension-btn ${currentDimension==='income'?'active':''}" id="btn-income">收入</button>
                <button class="dimension-btn ${currentDimension==='expense'?'active':''}" id="btn-expense">支出</button>
            </div>
            <div class="chart-switch-bar">
                <button class="switch-btn ${currentChartType==='bar'?'active':''}" id="btn-bar">柱状图</button>
                <button class="switch-btn ${currentChartType==='line'?'active':''}" id="btn-line2">折线图</button>
                <button class="switch-btn ${currentChartType==='pie'?'active':''}" id="btn-pie2">饼状图</button>
            </div>
            <canvas id="mainChart"></canvas>
        </div>`;
        chartsDiv.innerHTML = chartHTML;
        document.getElementById('btn-net').addEventListener('click', ()=> switchDimension('net'));
        document.getElementById('btn-income').addEventListener('click', ()=> switchDimension('income'));
        document.getElementById('btn-expense').addEventListener('click', ()=> switchDimension('expense'));
        document.getElementById('btn-bar').addEventListener('click', ()=> switchChartType('bar'));
        document.getElementById('btn-line2').addEventListener('click', ()=> switchChartType('line'));
        document.getElementById('btn-pie2').addEventListener('click', ()=> switchChartType('pie'));
        const ctx = document.getElementById('mainChart').getContext('2d');
        if(currentChartType === 'bar'){
            const data = selectedRoles.map(r => {
                if(currentDimension==='income') return roleStats[r.id].income;
                if(currentDimension==='expense') return roleStats[r.id].expense;
                return roleStats[r.id].income - roleStats[r.id].expense;
            });
            const bg = data.map(v => {
                if(currentDimension==='expense') return 'rgba(225,112,85,0.7)';
                if(currentDimension==='income') return 'rgba(0,184,148,0.7)';
                return v>=0?'rgba(0,184,148,0.7)':'rgba(225,112,85,0.7)';
            });
            analysisCharts.push(new Chart(ctx, {
                type:'bar', data:{labels:names, datasets:[{label:currentDimension==='net'?'净盈亏':(currentDimension==='income'?'收入':'支出'), data, backgroundColor:bg}]},
                options:{plugins:{title:{display:true,text:`各角色${currentDimension==='net'?'净盈亏':(currentDimension==='income'?'收入':'支出')}对比`}}}
            }));
        } else if(currentChartType === 'line'){
            const datasets = selectedRoles.map(r => {
                const color = '#'+Math.floor(Math.random()*16777215).toString(16).padStart(6,'0');
                const data = dates.map(d => {
                    const val = roleDailyMap[r.id]?.[d] || {income:0, expense:0};
                    if(currentDimension==='income') return val.income;
                    if(currentDimension==='expense') return val.expense;
                    return val.income - val.expense;
                });
                return {label:r.name, data, borderColor:color, tension:0.3, fill:false};
            });
            analysisCharts.push(new Chart(ctx, {
                type:'line', data:{labels:dates, datasets},
                options:{plugins:{title:{display:true,text:`各角色${currentDimension==='net'?'净盈亏':(currentDimension==='income'?'收入':'支出')}趋势`}}}
            }));
        } else {
            const data = selectedRoles.map(r => {
                if(currentDimension==='income') return roleStats[r.id].income;
                if(currentDimension==='expense') return roleStats[r.id].expense;
                return roleStats[r.id].income - roleStats[r.id].expense;
            });
            const bg = ['#6c5ce7','#00b894','#e17055','#fdcb6e','#a29bfe','#fd79a8','#0984e3','#e84393'];
            analysisCharts.push(new Chart(ctx, {
                type:'pie', data:{labels:names, datasets:[{data, backgroundColor:bg.slice(0, names.length)}]},
                options:{plugins:{title:{display:true,text:`各角色${currentDimension==='net'?'净盈亏':(currentDimension==='income'?'收入':'支出')}占比`}}}
            }));
        }
    }
}
function switchChartType(type){ currentChartType = type; renderAnalysis(); }
function switchDimension(dim){ currentDimension = dim; renderAnalysis(); }
function showAnalysisRolePicker(){
    const selectedIds = getAnalysisSelectedIds();
    const selectedSet = new Set(selectedIds);
    const selectedRoles = appRoles.filter(r => selectedSet.has(r.id));
    const unselectedRoles = appRoles.filter(r => !selectedSet.has(r.id));
    let html = `<div class="modal-overlay" onclick="closeModal()"><div class="modal" onclick="event.stopPropagation()"><h3>选择角色 <button class="close-btn" onclick="closeModal()">×</button></h3>
        <div style="display:flex;justify-content:space-between;align-items:center;margin:6px 0;">
            <div>
                <button class="btn btn-sm" id="selectAllModalRoles">全选</button>
                <button class="btn btn-sm" id="clearAllModalRoles" style="margin-left:8px;">取消全选</button>
            </div>
            <div id="modalSelectionSummary" style="color:var(--text-light);font-size:0.9rem;">已选 ${selectedRoles.length} / 共 ${appRoles.length} 人</div>
        </div>
        <div style="display:flex;gap:12px;">
            <div style="flex:1;">
                <h4 style="margin:6px 0;">已选 (${selectedRoles.length})</h4>
                <div id="modalSelectedRoles" style="display:flex;flex-direction:column;gap:6px;max-height:300px;overflow:auto;">`;
    selectedRoles.forEach(r => {
        html += `<div class="role-card selected" data-roleid="${r.id}"><strong>${r.name}</strong><span style="font-size:0.8rem;color:var(--text-light);margin-left:6px;">${r.server} · ${getFactionAbbr(r.faction)}</span></div>`;
    });
    html += `</div></div>
            <div style="flex:1;">
                <h4 style="margin:6px 0;">未选 (${unselectedRoles.length})</h4>
                <div id="modalUnselectedRoles" style="display:flex;flex-direction:column;gap:6px;max-height:300px;overflow:auto;">`;
    unselectedRoles.forEach(r => {
        html += `<div class="role-card" data-roleid="${r.id}"><strong>${r.name}</strong><span style="font-size:0.8rem;color:var(--text-light);margin-left:6px;">${r.server} · ${getFactionAbbr(r.faction)}</span></div>`;
    });
    html += `</div></div>
        </div>
        <div style="margin-top:12px;text-align:right;"><button class="btn btn-primary" id="applyAnalysisRoles" style="min-width:84px;padding:8px 12px;">应用</button></div>
    </div></div>`;
    document.getElementById('modalContainer').innerHTML = html;
    function bindModalHandlers(){
        document.querySelectorAll('.modal .role-card').forEach(card => {
            card.addEventListener('click', function(){
                const rid = this.dataset.roleid;
                if(this.classList.contains('selected')){
                    this.classList.remove('selected');
                    document.getElementById('modalUnselectedRoles').appendChild(this);
                } else {
                    this.classList.add('selected');
                    document.getElementById('modalSelectedRoles').appendChild(this);
                }
                const cnt = document.querySelectorAll('#modalSelectedRoles .role-card').length;
                const total = appRoles.length;
                const el = document.getElementById('modalSelectionSummary'); if(el) el.textContent = `已选 ${cnt} / 共 ${total} 人`;
            });
        });
        const selAllBtn = document.getElementById('selectAllModalRoles');
        if(selAllBtn){
            selAllBtn.addEventListener('click', function(){
                document.querySelectorAll('.modal .role-card').forEach(c=>{
                    if(!c.classList.contains('selected')){
                        c.classList.add('selected');
                        document.getElementById('modalSelectedRoles').appendChild(c);
                    }
                });
                const el = document.getElementById('modalSelectionSummary'); if(el) el.textContent = `已选 ${document.querySelectorAll('#modalSelectedRoles .role-card').length} / 共 ${appRoles.length} 人`;
            });
        }
        const clearBtn = document.getElementById('clearAllModalRoles');
        if(clearBtn){
            clearBtn.addEventListener('click', function(){
                [...document.querySelectorAll('#modalSelectedRoles .role-card')].forEach(c=>{
                    c.classList.remove('selected');
                    document.getElementById('modalUnselectedRoles').appendChild(c);
                });
                const el = document.getElementById('modalSelectionSummary'); if(el) el.textContent = `已选 0 / 共 ${appRoles.length} 人`;
            });
        }
        document.getElementById('applyAnalysisRoles').addEventListener('click', function(){
            const ids = [...document.querySelectorAll('#modalSelectedRoles .role-card')].map(c=>c.dataset.roleid);
            analysisSelectedRoleIds = ids;
            closeModal();
            renderAnalysisRoleCards();
            renderAnalysis();
        });
    }
    bindModalHandlers();
}
function initAnalysisPage(){
    renderAnalysisRoleCards();
    document.getElementById('analysisPeriod').addEventListener('change', function(){
        document.getElementById('customDateLabel').style.display = this.value==='custom'?'':'none';
        renderAnalysis();
    });
    document.getElementById('analysisStart').addEventListener('change', renderAnalysis);
    document.getElementById('analysisEnd').addEventListener('change', renderAnalysis);
    if(!document.getElementById('analysisStart').value){
        const now = new Date();
        document.getElementById('analysisStart').value = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
        document.getElementById('analysisEnd').value = now.toISOString().split('T')[0];
    }
}
function getAnalysisRange(){
    const period = document.getElementById('analysisPeriod').value;
    const today = new Date(); today.setHours(23,59,59,999);
    if(period === 'day') return {start:new Date(new Date().setHours(0,0,0,0)), end:today};
    if(period === 'week'){
        const d = new Date();
        const day = d.getDay();
        const s = new Date(d);
        s.setDate(d.getDate() - (day===0?6:day-1));
        s.setHours(0,0,0,0);
        const e = new Date(s);
        e.setDate(s.getDate() + 6);
        e.setHours(23,59,59,999);
        return {start:s, end:e};
    }
    if(period === 'month') return {start:new Date(today.getFullYear(), today.getMonth(), 1), end:today};
    return { start:new Date(document.getElementById('analysisStart').value), end:new Date(document.getElementById('analysisEnd').value + 'T23:59:59') };
}

// ==================== 初始化 ====================
function init(){
    initTheme();
    document.getElementById('currencyUnit').value = currencyData.unit;
    document.getElementById('bigUnit').value = currencyData.bigUnit || '';
    document.getElementById('unitRate').value = currencyData.rate || 10000;
    document.getElementById('recordDatePicker').value = getToday();
    document.getElementById('recordDatePicker').style.display = '';
    document.getElementById('currencyUnit').addEventListener('change', saveCurrencyUnit);
    document.getElementById('bigUnit').addEventListener('change', saveCurrencyUnit);
    document.getElementById('unitRate').addEventListener('change', saveCurrencyUnit);
    document.getElementById('btn-export').addEventListener('click', exportData);
    document.getElementById('btn-import').addEventListener('click', importData);
    document.getElementById('btn-clear-data').addEventListener('click', clearHistoryData);
    document.querySelectorAll('.theme-option').forEach(opt => {
        opt.addEventListener('click', function(){ setTheme(this.dataset.theme); });
    });
    document.getElementById('btn-add-showcase').addEventListener('click', function(){
        toggleFabMenu();
        showAddShowcaseModal();
    });
    renderHome();
    renderRecordRoleList();
    updateFilterOptions();
}

// ==================== 奇遇展示功能 - 洞洞板风格 ====================
const STORAGE_SHOWCASE = 'showcase_items';
let currentShowcaseImage = null;
let currentShowcaseStyle = 'badge';

function loadShowcaseItems(){
    let items = JSON.parse(localStorage.getItem(STORAGE_SHOWCASE)) || [];
    items = migrateShowcaseItems(items);
    return items;
}

function migrateShowcaseItems(items){
    let hasChanges = false;
    const migrated = items.map(item => {
        const newItem = {...item};
        if(!newItem.style){
            newItem.style = Math.random() > 0.5 ? 'badge' : 'polaroid';
            hasChanges = true;
        }
        if(newItem.rotation === undefined || newItem.rotation === null){
            newItem.rotation = getRandomRotation();
            hasChanges = true;
        }
        if(newItem.positionX === undefined || newItem.positionX === null){
            newItem.positionX = null;
            hasChanges = true;
        }
        if(newItem.positionY === undefined || newItem.positionY === null){
            newItem.positionY = null;
            hasChanges = true;
        }
        if(newItem.style === 'badge' && !newItem.croppedImageBase64){
            newItem.croppedImageBase64 = newItem.imageBase64;
            hasChanges = true;
        }
        return newItem;
    });
    if(hasChanges){
        localStorage.setItem(STORAGE_SHOWCASE, JSON.stringify(migrated));
    }
    return migrated;
}

function getRandomRotation(min = -15, max = 15){
    return Math.round((Math.random() * (max - min) + min) * 10) / 10;
}

function saveShowcaseItem(item){
    const items = loadShowcaseItems();
    items.unshift(item);
    localStorage.setItem(STORAGE_SHOWCASE, JSON.stringify(items));
}

function deleteShowcaseItem(id){
    const items = loadShowcaseItems().filter(i => i.id !== id);
    localStorage.setItem(STORAGE_SHOWCASE, JSON.stringify(items));
}

function compressImage(file, maxWidth = 600, quality = 0.7){
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = function(e){
            const img = new Image();
            img.onload = function(){
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;
                if(width > maxWidth){
                    height = (height * maxWidth) / width;
                    width = maxWidth;
                }
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);
                let result = canvas.toDataURL('image/jpeg', quality);
                const sizeKB = Math.round((result.length * 3) / 4 / 1024);
                if(sizeKB > 150 && quality > 0.3){
                    result = canvas.toDataURL('image/jpeg', quality - 0.2);
                }
                resolve(result);
            };
            img.onerror = reject;
            img.src = e.target.result;
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

function cropImage(imageBase64, cropX, cropY, cropWidth, cropHeight){
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = function(){
            const canvas = document.createElement('canvas');
            canvas.width = cropWidth;
            canvas.height = cropHeight;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, cropX, cropY, cropWidth, cropHeight, 0, 0, cropWidth, cropHeight);
            let result = canvas.toDataURL('image/jpeg', 0.85);
            const sizeKB = Math.round((result.length * 3) / 4 / 1024);
            if(sizeKB > 150){
                result = canvas.toDataURL('image/jpeg', 0.7);
            }
            resolve(result);
        };
        img.onerror = reject;
        img.src = imageBase64;
    });
}

function cropCircle(imageBase64, centerX, centerY, radius){
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = function(){
            const canvas = document.createElement('canvas');
            canvas.width = radius * 2;
            canvas.height = radius * 2;
            const ctx = canvas.getContext('2d');
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.beginPath();
            ctx.arc(radius, radius, radius, 0, Math.PI * 2);
            ctx.closePath();
            ctx.clip();
            ctx.drawImage(img, centerX - radius, centerY - radius, radius * 2, radius * 2, 0, 0, radius * 2, radius * 2);
            let result = canvas.toDataURL('image/jpeg', 0.85);
            const sizeKB = Math.round((result.length * 3) / 4 / 1024);
            if(sizeKB > 150){
                result = canvas.toDataURL('image/jpeg', 0.7);
            }
            resolve(result);
        };
        img.onerror = reject;
        img.src = imageBase64;
    });
}

function getRandomRotation(min = -2, max = 2){
    return Math.round((Math.random() * (max - min) + min) * 10) / 10;
}

function lazyLoadImages(container){
    const images = container.querySelectorAll('[data-bg]');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if(entry.isIntersecting){
                const el = entry.target;
                const bg = el.dataset.bg;
                if(bg){
                    el.style.backgroundImage = `url('${bg}')`;
                    el.removeAttribute('data-bg');
                }
                observer.unobserve(el);
            }
        });
    }, { rootMargin: '100px' });
    
    images.forEach(img => observer.observe(img));
}

function renderShowcaseGrid(){
    const container = document.getElementById('showcaseBoard');
    if(!container) return;
    const items = loadShowcaseItems();
    if(!items.length){
        container.innerHTML = `
            <div class="showcase-empty">
                <div class="empty-icon">✨</div>
                <h3>还没有奇遇记录</h3>
                <p>点击右下角 <strong>+</strong> 按钮，选择 <strong>📸 添加奇遇</strong> 开始记录你的江湖奇遇吧！</p>
            </div>`;
        return;
    }
    
    const containerRect = container.getBoundingClientRect();
    const containerWidth = containerRect.width - 80;
    const containerHeight = Math.max(600, containerRect.height) - 120;
    
    let html = '';
    const usedPositions = [];
    
    items.forEach((item, index) => {
        const role = appRoles.find(r => r.id === item.roleId);
        let rotation = item.rotation;
        if(rotation === undefined || rotation === null || Math.abs(rotation) > 3){
            rotation = getRandomRotation();
        }
        const animDelay = Math.min(index * 0.08, 0.6);
        
        let posX = item.positionX;
        let posY = item.positionY;
        
        if(posX === null || posX === undefined || posY === null || posY === undefined){
            let attempts = 0;
            let overlap = true;
            const itemWidth = item.style === 'badge' ? 158 : 170;
            const itemHeight = item.style === 'badge' ? 158 : 225;
            
            while(overlap && attempts < 50){
                posX = Math.random() * (containerWidth - itemWidth);
                posY = Math.random() * (containerHeight - itemHeight);
                overlap = usedPositions.some(pos => 
                    Math.abs(pos.x - posX) < itemWidth && 
                    Math.abs(pos.y - posY) < itemHeight
                );
                attempts++;
            }
            usedPositions.push({x: posX, y: posY});
        }
        
        const imageUrl = (item.style === 'badge' && item.croppedImageBase64) ? item.croppedImageBase64 : item.imageBase64;
        
        if(item.style === 'badge'){
            html += `<div class="showcase-badge" data-id="${item.id}" style="left:${posX}px; top:${posY}px; transform: rotate(${rotation}deg); animation-delay:${animDelay}s;">
                <div class="badge-image" data-bg="${imageUrl}"></div>
                <div class="badge-shine"></div>
                <div class="badge-glitter"></div>
                <div class="badge-texture"></div>
                <div class="badge-pin-back"></div>
                <button class="showcase-pin" data-id="${item.id}" title="点击删除"></button>
            </div>`;
        } else {
            html += `<div class="showcase-polaroid" data-id="${item.id}" style="left:${posX}px; top:${posY}px; transform: rotate(${rotation}deg); animation-delay:${animDelay}s;">
                <div class="polaroid-image" data-bg="${item.imageBase64}"></div>
                <div class="polaroid-caption">${escapeHtml(item.description)}</div>
                <div class="polaroid-date">${item.date || ''}</div>
                <button class="showcase-pin" data-id="${item.id}" title="点击删除"></button>
            </div>`;
        }
    });
    container.innerHTML = html;
    
    lazyLoadImages(container);
    initDraggable();
    initPinButtons();
}

function initDraggable(){
    const container = document.getElementById('showcaseBoard');
    if(!container) return;
    
    const cards = container.querySelectorAll('.showcase-badge, .showcase-polaroid');
    let highestZ = 1;
    
    cards.forEach(card => {
        let isDragging = false;
        let startX = 0, startY = 0;
        let initialLeft = 0, initialTop = 0;
        let hasMoved = false;
        
        const pin = card.querySelector('.showcase-pin');
        
        const onMouseDown = function(e){
            if(e.target === pin) return;
            
            e.preventDefault();
            isDragging = true;
            hasMoved = false;
            card.classList.add('dragging');
            
            highestZ++;
            card.style.zIndex = highestZ;
            
            const clientX = e.type.includes('touch') ? e.touches[0].clientX : e.clientX;
            const clientY = e.type.includes('touch') ? e.touches[0].clientY : e.clientY;
            
            startX = clientX;
            startY = clientY;
            initialLeft = parseInt(card.style.left) || 0;
            initialTop = parseInt(card.style.top) || 0;
            
            document.addEventListener('mousemove', onMouseMove);
            document.addEventListener('mouseup', onMouseUp);
            document.addEventListener('touchmove', onMouseMove, {passive: false});
            document.addEventListener('touchend', onMouseUp);
        };
        
        const onMouseMove = function(e){
            if(!isDragging) return;
            e.preventDefault();
            hasMoved = true;
            
            const clientX = e.type.includes('touch') ? e.touches[0].clientX : e.clientX;
            const clientY = e.type.includes('touch') ? e.touches[0].clientY : e.clientY;
            
            const deltaX = clientX - startX;
            const deltaY = clientY - startY;
            
            const containerRect = container.getBoundingClientRect();
            const cardRect = card.getBoundingClientRect();
            
            let newLeft = initialLeft + deltaX;
            let newTop = initialTop + deltaY;
            
            const maxLeft = containerRect.width - cardRect.width - 20;
            const maxTop = containerRect.height - cardRect.height - 20;
            
            newLeft = Math.max(20, Math.min(maxLeft, newLeft));
            newTop = Math.max(20, Math.min(maxTop, newTop));
            
            card.style.left = `${newLeft}px`;
            card.style.top = `${newTop}px`;
        };
        
        const onMouseUp = function(){
            if(!isDragging) return;
            isDragging = false;
            card.classList.remove('dragging');
            
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
            document.removeEventListener('touchmove', onMouseMove);
            document.removeEventListener('touchend', onMouseUp);
            
            if(hasMoved){
                const itemId = card.dataset.id;
                const items = loadShowcaseItems();
                const item = items.find(i => i.id === itemId);
                if(item){
                    item.positionX = parseInt(card.style.left);
                    item.positionY = parseInt(card.style.top);
                    localStorage.setItem(STORAGE_SHOWCASE, JSON.stringify(items));
                }
            } else {
                const itemId = card.dataset.id;
                showShowcaseDetail(itemId);
            }
        };
        
        card.addEventListener('mousedown', onMouseDown);
        card.addEventListener('touchstart', onMouseDown, {passive: false});
    });
}

function initPinButtons(){
    const pins = document.querySelectorAll('.showcase-pin');
    pins.forEach(pin => {
        pin.addEventListener('click', function(e){
            e.stopPropagation();
            const itemId = this.dataset.id;
            showDeleteConfirm(itemId, this);
        });
    });
}

function showDeleteConfirm(itemId, pinElement){
    const card = pinElement.closest('.showcase-badge, .showcase-polaroid');
    
    const overlay = document.createElement('div');
    overlay.className = 'showcase-detail-overlay';
    overlay.innerHTML = `
        <div class="showcase-detail-card" style="max-width:400px; text-align:center;">
            <button class="showcase-detail-close" onclick="this.closest('.showcase-detail-overlay').remove()">×</button>
            <div style="padding:30px 20px;">
                <div style="font-size:3rem; margin-bottom:16px;">🗑️</div>
                <h3 style="margin:0 0 12px 0; color:var(--text);">确定删除吗？</h3>
                <p style="color:var(--text-light); margin-bottom:24px;">删除后将无法恢复，图钉和卡片会一起掉落哦~</p>
                <div style="display:flex; gap:12px; justify-content:center;">
                    <button class="btn" style="flex:1; padding:12px; border-radius:8px; border:1px solid var(--border); background:var(--card-bg); cursor:pointer;" onclick="this.closest('.showcase-detail-overlay').remove()">取消</button>
                    <button class="btn btn-primary" id="confirmDeleteBtn" style="flex:1; padding:12px; border-radius:8px; background:var(--danger); color:#fff; border:none; cursor:pointer;">确认删除</button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(overlay);
    
    overlay.querySelector('#confirmDeleteBtn').addEventListener('click', function(){
        overlay.remove();
        confirmDeleteShowcase(itemId, card, pinElement);
    });
    
    overlay.addEventListener('click', function(e){
        if(e.target === overlay) overlay.remove();
    });
}

function playDropAnimation(card, pin, callback){
    const board = document.getElementById('showcaseBoard');
    const boardRect = board.getBoundingClientRect();
    const cardRect = card.getBoundingClientRect();
    const pinRect = pin.getBoundingClientRect();
    
    card.style.transition = 'none';
    pin.style.transition = 'none';
    
    const cardClone = card.cloneNode(true);
    const pinClone = pin.cloneNode(true);
    
    cardClone.className = 'showcase-badge dropping';
    pinClone.className = 'showcase-pin pin-dropping';
    
    cardClone.style.left = `${cardRect.left}px`;
    cardClone.style.top = `${cardRect.top}px`;
    cardClone.style.width = `${cardRect.width}px`;
    cardClone.style.height = `${cardRect.height}px`;
    cardClone.style.transform = card.style.transform;
    cardClone.style.zIndex = '9999';
    cardClone.style.position = 'fixed';
    cardClone.style.pointerEvents = 'none';
    
    pinClone.style.left = `${pinRect.left}px`;
    pinClone.style.top = `${pinRect.top}px`;
    pinClone.style.position = 'fixed';
    pinClone.style.zIndex = '10000';
    pinClone.style.pointerEvents = 'none';
    
    document.body.appendChild(cardClone);
    document.body.appendChild(pinClone);
    
    card.style.opacity = '0';
    pin.style.opacity = '0';
    
    const physics = {
        gravity: 0.6,
        bounce: 0.55,
        friction: 0.97,
        airResistance: 0.995
    };
    
    let cardVelocityY = -2 + Math.random() * -3;
    let cardVelocityX = (Math.random() - 0.5) * 6;
    let cardRotation = 0;
    let cardRotationSpeed = (Math.random() - 0.5) * 12;
    
    let pinVelocityY = -3 + Math.random() * -4;
    let pinVelocityX = (Math.random() - 0.5) * 8;
    let pinRotation = 0;
    let pinRotationSpeed = (Math.random() - 0.5) * 20;
    
    const groundY = window.innerHeight - cardRect.height - 10;
    const pinGroundY = window.innerHeight - pinRect.height - 10;
    
    let cardBounceCount = 0;
    let pinBounceCount = 0;
    const maxBounces = 4;
    
    function animate(){
        cardVelocityY += physics.gravity;
        cardVelocityX *= physics.airResistance;
        cardVelocityY *= physics.airResistance;
        
        let cardY = parseFloat(cardClone.style.top) + cardVelocityY;
        let cardX = parseFloat(cardClone.style.left) + cardVelocityX;
        cardRotation += cardRotationSpeed;
        cardRotationSpeed *= physics.friction;
        
        if(cardY > groundY){
            cardY = groundY;
            if(cardBounceCount < maxBounces && Math.abs(cardVelocityY) > 2){
                cardVelocityY = -cardVelocityY * physics.bounce;
                cardVelocityX *= physics.friction;
                cardBounceCount++;
            } else {
                cardVelocityY = 0;
                cardVelocityX *= 0.9;
                cardRotationSpeed *= 0.8;
            }
        }
        
        if(cardX < 0){ cardX = 0; cardVelocityX = -cardVelocityX * physics.bounce; }
        if(cardX > window.innerWidth - cardRect.width){ 
            cardX = window.innerWidth - cardRect.width; 
            cardVelocityX = -cardVelocityX * physics.bounce; 
        }
        
        cardClone.style.top = `${cardY}px`;
        cardClone.style.left = `${cardX}px`;
        cardClone.style.transform = `rotate(${cardRotation}deg)`;
        
        pinVelocityY += physics.gravity * 0.9;
        pinVelocityX *= physics.airResistance;
        
        let pinY = parseFloat(pinClone.style.top) + pinVelocityY;
        let pinX = parseFloat(pinClone.style.left) + pinVelocityX;
        pinRotation += pinRotationSpeed;
        pinRotationSpeed *= physics.friction;
        
        if(pinY > pinGroundY){
            pinY = pinGroundY;
            if(pinBounceCount < maxBounces && Math.abs(pinVelocityY) > 2){
                pinVelocityY = -pinVelocityY * (physics.bounce - 0.1);
                pinVelocityX *= physics.friction;
                pinBounceCount++;
            } else {
                pinVelocityY = 0;
                pinVelocityX *= 0.9;
                pinRotationSpeed *= 0.8;
            }
        }
        
        if(pinX < 0){ pinX = 0; pinVelocityX = -pinVelocityX * physics.bounce; }
        if(pinX > window.innerWidth - pinRect.width){ 
            pinX = window.innerWidth - pinRect.width; 
            pinVelocityX = -pinVelocityX * physics.bounce; 
        }
        
        pinClone.style.top = `${pinY}px`;
        pinClone.style.left = `${pinX}px`;
        pinClone.style.transform = `translateX(-50%) rotate(${pinRotation}deg)`;
        
        const cardStopped = Math.abs(cardVelocityY) < 0.5 && Math.abs(cardVelocityX) < 0.5 && Math.abs(cardRotationSpeed) < 0.5;
        const pinStopped = Math.abs(pinVelocityY) < 0.5 && Math.abs(pinVelocityX) < 0.5 && Math.abs(pinRotationSpeed) < 0.5;
        
        if(cardStopped && pinStopped){
            let opacity = 1;
            function fadeOut(){
                opacity -= 0.05;
                cardClone.style.opacity = opacity;
                pinClone.style.opacity = opacity;
                if(opacity > 0){
                    requestAnimationFrame(fadeOut);
                } else {
                    cardClone.remove();
                    pinClone.remove();
                    card.remove();
                    if(callback) callback();
                }
            }
            fadeOut();
        } else {
            requestAnimationFrame(animate);
        }
    }
    
    animate();
}

function confirmDeleteShowcase(id, card, pin){
    if(!card){
        card = document.querySelector(`[data-id="${id}"]`);
    }
    if(!pin && card){
        pin = card.querySelector('.showcase-pin');
    }
    
    const doDelete = function(){
        deleteShowcaseItem(id);
        renderShowcaseGrid();
    };
    
    if(card && pin){
        playDropAnimation(card, pin, doDelete);
    } else {
        doDelete();
    }
}

let currentCroppedImage = null;
let cropperState = {
    image: null,
    centerX: 0,
    centerY: 0,
    radius: 50,
    isDragging: false,
    isResizing: false,
    startX: 0,
    startY: 0,
    imageDisplayWidth: 0,
    imageDisplayHeight: 0,
    imageOffsetX: 0,
    imageOffsetY: 0,
    scaleX: 1,
    scaleY: 1
};

function showCropperModal(imageBase64, callback){
    currentCroppedImage = null;
    cropperState = {
        image: null,
        centerX: 0,
        centerY: 0,
        radius: 50,
        isDragging: false,
        isResizing: false,
        startX: 0,
        startY: 0,
        imageDisplayWidth: 0,
        imageDisplayHeight: 0,
        imageOffsetX: 0,
        imageOffsetY: 0,
        scaleX: 1,
        scaleY: 1
    };
    
    const overlay = document.createElement('div');
    overlay.className = 'showcase-detail-overlay';
    overlay.id = 'cropperOverlay';
    overlay.innerHTML = `
        <div class="showcase-detail-card" style="max-width:600px;">
            <button class="showcase-detail-close" onclick="document.getElementById('cropperOverlay').remove()">×</button>
            <div style="padding:20px;">
                <h3 style="margin:0 0 16px 0; text-align:center;">✂️ 框选吧唧封面</h3>
                <p style="text-align:center; color:var(--text-light); margin-bottom:16px; font-size:0.9rem;">拖动圆形选择封面区域，拖动右下角调整大小</p>
                <div class="cropper-container" id="cropperContainer">
                    <img id="cropperImage" class="cropper-image" src="${imageBase64}" alt="裁剪图片">
                    <div class="cropper-box" id="cropperBox"></div>
                </div>
                <div class="cropper-preview">
                    <div id="cropperPreviewBadge" class="cropper-preview-badge"></div>
                    <div class="cropper-preview-label">预览效果</div>
                </div>
                <div class="cropper-controls">
                    <button id="cropResetBtn">重置</button>
                    <button id="cropZoomInBtn">放大 +</button>
                    <button id="cropZoomOutBtn">缩小 -</button>
                </div>
                <div style="display:flex; gap:12px; margin-top:16px;">
                    <button class="btn" style="flex:1; padding:12px; border-radius:8px; border:1px solid var(--border); background:var(--card-bg); cursor:pointer;" onclick="document.getElementById('cropperOverlay').remove()">取消</button>
                    <button class="btn btn-primary" id="cropConfirmBtn" style="flex:1; padding:12px; border-radius:8px; background:var(--primary); color:#fff; border:none; cursor:pointer;">确认裁剪</button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(overlay);
    
    const img = overlay.querySelector('#cropperImage');
    const cropperBox = overlay.querySelector('#cropperBox');
    const container = overlay.querySelector('#cropperContainer');
    const previewBadge = overlay.querySelector('#cropperPreviewBadge');
    
    img.onload = function(){
        cropperState.image = img;
        
        setTimeout(() => {
            const containerRect = container.getBoundingClientRect();
            const imgRect = img.getBoundingClientRect();
            
            cropperState.imageDisplayWidth = imgRect.width;
            cropperState.imageDisplayHeight = imgRect.height;
            cropperState.imageOffsetX = imgRect.left - containerRect.left;
            cropperState.imageOffsetY = imgRect.top - containerRect.top;
            cropperState.scaleX = img.naturalWidth / imgRect.width;
            cropperState.scaleY = img.naturalHeight / imgRect.height;
            
            const minDim = Math.min(imgRect.width, imgRect.height);
            cropperState.radius = minDim * 0.35;
            cropperState.centerX = imgRect.width / 2;
            cropperState.centerY = imgRect.height / 2;
            
            updateCropperBox();
            updatePreview();
        }, 50);
    };
    
    function updateCropperBox(){
        const boxSize = cropperState.radius * 2;
        cropperBox.style.width = `${boxSize}px`;
        cropperBox.style.height = `${boxSize}px`;
        cropperBox.style.left = `${cropperState.imageOffsetX + cropperState.centerX - cropperState.radius}px`;
        cropperBox.style.top = `${cropperState.imageOffsetY + cropperState.centerY - cropperState.radius}px`;
        cropperBox.style.borderRadius = '50%';
    }
    
    function updatePreview(){
        const cx = cropperState.centerX * cropperState.scaleX;
        const cy = cropperState.centerY * cropperState.scaleY;
        const r = cropperState.radius * cropperState.scaleX;
        
        const canvas = document.createElement('canvas');
        canvas.width = r * 2;
        canvas.height = r * 2;
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.beginPath();
        ctx.arc(r, r, r, 0, Math.PI * 2);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(img, cx - r, cy - r, r * 2, r * 2, 0, 0, r * 2, r * 2);
        previewBadge.style.backgroundImage = `url(${canvas.toDataURL('image/jpeg', 0.8)})`;
    }
    
    const onMouseDown = function(e){
        e.preventDefault();
        const rect = cropperBox.getBoundingClientRect();
        const containerRect = container.getBoundingClientRect();
        const clientX = e.clientX;
        const clientY = e.clientY;
        
        const handleX = rect.right - containerRect.left;
        const handleY = rect.bottom - containerRect.top;
        const clickX = clientX - containerRect.left;
        const clickY = clientY - containerRect.top;
        
        if(Math.abs(clickX - handleX) < 15 && Math.abs(clickY - handleY) < 15){
            cropperState.isResizing = true;
        } else {
            cropperState.isDragging = true;
        }
        
        cropperState.startX = clientX;
        cropperState.startY = clientY;
        
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    };
    
    const onMouseMove = function(e){
        e.preventDefault();
        const clientX = e.clientX;
        const clientY = e.clientY;
        const deltaX = clientX - cropperState.startX;
        const deltaY = clientY - cropperState.startY;
        
        if(cropperState.isDragging){
            let newCenterX = cropperState.centerX + deltaX;
            let newCenterY = cropperState.centerY + deltaY;
            
            newCenterX = Math.max(cropperState.radius, Math.min(cropperState.imageDisplayWidth - cropperState.radius, newCenterX));
            newCenterY = Math.max(cropperState.radius, Math.min(cropperState.imageDisplayHeight - cropperState.radius, newCenterY));
            
            cropperState.centerX = newCenterX;
            cropperState.centerY = newCenterY;
        } else if(cropperState.isResizing){
            const delta = Math.max(deltaX, deltaY);
            let newRadius = cropperState.radius + delta * 0.5;
            const minRadius = 30;
            const maxRadius = Math.min(cropperState.imageDisplayWidth, cropperState.imageDisplayHeight) / 2;
            newRadius = Math.max(minRadius, Math.min(maxRadius, newRadius));
            
            cropperState.radius = newRadius;
        }
        
        cropperState.startX = clientX;
        cropperState.startY = clientY;
        
        updateCropperBox();
        updatePreview();
    };
    
    const onMouseUp = function(){
        cropperState.isDragging = false;
        cropperState.isResizing = false;
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
    };
    
    cropperBox.addEventListener('mousedown', onMouseDown);
    
    overlay.querySelector('#cropResetBtn').addEventListener('click', function(){
        const minDim = Math.min(cropperState.imageDisplayWidth, cropperState.imageDisplayHeight);
        cropperState.radius = minDim * 0.35;
        cropperState.centerX = cropperState.imageDisplayWidth / 2;
        cropperState.centerY = cropperState.imageDisplayHeight / 2;
        updateCropperBox();
        updatePreview();
    });
    
    overlay.querySelector('#cropZoomInBtn').addEventListener('click', function(){
        cropperState.radius = Math.min(cropperState.radius * 1.2, Math.min(cropperState.imageDisplayWidth, cropperState.imageDisplayHeight) / 2);
        updateCropperBox();
        updatePreview();
    });
    
    overlay.querySelector('#cropZoomOutBtn').addEventListener('click', function(){
        cropperState.radius = Math.max(cropperState.radius * 0.8, 30);
        updateCropperBox();
        updatePreview();
    });
    
    overlay.querySelector('#cropConfirmBtn').addEventListener('click', async function(){
        const cx = cropperState.centerX * cropperState.scaleX;
        const cy = cropperState.centerY * cropperState.scaleY;
        const r = cropperState.radius * cropperState.scaleX;
        
        currentCroppedImage = await cropCircle(imageBase64, cx, cy, r);
        overlay.remove();
        if(callback) callback(currentCroppedImage);
    });
}

function showAddShowcaseModal(){
    const today = getToday();
    currentShowcaseStyle = 'badge';
    currentCroppedImage = null;
    
    let html = `<div class="modal-overlay" onclick="closeModal()"><div class="modal showcase-modal" onclick="event.stopPropagation()">
        <h3>📸 添加奇遇 <button class="close-btn" onclick="closeModal()">×</button></h3>
        <div id="showcaseUploadArea" class="showcase-upload-area" onclick="document.getElementById('showcaseImageInput').click()">
            <div class="showcase-upload-icon">📷</div>
            <div class="showcase-upload-text">点击选择图片<br><small>支持 JPG / PNG / WebP，自动压缩</small></div>
        </div>
        <input type="file" id="showcaseImageInput" accept="image/jpeg,image/png,image/webp" style="display:none;">
        <div id="cropButtonContainer" style="display:none; margin-bottom:16px;">
            <button class="btn" id="cropBtn" style="width:100%; padding:12px; border-radius:8px; border:1px solid var(--primary); background:var(--tag-bg); color:var(--primary); cursor:pointer;">✂️ 裁剪吧唧封面</button>
        </div>
        <div class="showcase-style-select">
            <div class="style-option selected" data-style="badge" onclick="selectShowcaseStyle('badge')">
                <div class="style-preview">🎖️</div>
                <div class="style-label">吧唧</div>
            </div>
            <div class="style-option" data-style="polaroid" onclick="selectShowcaseStyle('polaroid')">
                <div class="style-preview">📷</div>
                <div class="style-label">拍立得</div>
            </div>
        </div>
        <div class="form-row">
            <label style="flex:1;">描述
                <input type="text" id="showcaseDesc" placeholder="例如：济苍生！欧气爆棚" style="width:100%;">
            </label>
        </div>
        <div class="form-row">
            <label>发生日期
                <input type="date" id="showcaseDate" value="${today}">
            </label>
            <label style="flex:1;">关联角色
                <select id="showcaseRole" class="showcase-role-select">
                    <option value="">不关联</option>
                    ${appRoles.map(r => `<option value="${r.id}">${escapeHtml(r.name)}</option>`).join('')}
                </select>
            </label>
        </div>
        <button class="btn btn-primary" id="saveShowcaseBtn" style="width:100%;" disabled>✨ 保存奇遇</button>
    </div></div>`;
    document.getElementById('modalContainer').innerHTML = html;
    
    window.selectShowcaseStyle = function(style){
        currentShowcaseStyle = style;
        document.querySelectorAll('.style-option').forEach(opt => {
            opt.classList.toggle('selected', opt.dataset.style === style);
        });
        const cropContainer = document.getElementById('cropButtonContainer');
        if(currentShowcaseImage && style === 'badge'){
            cropContainer.style.display = 'block';
        } else {
            cropContainer.style.display = 'none';
        }
    };
    
    document.getElementById('showcaseImageInput').addEventListener('change', async function(e){
        const file = e.target.files[0];
        if(!file) return;
        if(!['image/jpeg','image/png','image/webp'].includes(file.type)){
            alert('请选择 JPG、PNG 或 WebP 格式的图片');
            return;
        }
        try {
            currentShowcaseImage = await compressImage(file);
            currentCroppedImage = null;
            const uploadArea = document.getElementById('showcaseUploadArea');
            uploadArea.classList.add('has-image');
            uploadArea.innerHTML = `<img src="${currentShowcaseImage}" class="showcase-preview" alt="预览">`;
            document.getElementById('saveShowcaseBtn').disabled = false;
            
            const cropContainer = document.getElementById('cropButtonContainer');
            if(currentShowcaseStyle === 'badge'){
                cropContainer.style.display = 'block';
            }
        } catch(err){
            alert('图片处理失败，请重试');
            console.error(err);
        }
    });
    
    document.getElementById('cropBtn').addEventListener('click', function(){
        if(!currentShowcaseImage) return;
        showCropperModal(currentShowcaseImage, function(croppedImage){
            currentCroppedImage = croppedImage;
            const uploadArea = document.getElementById('showcaseUploadArea');
            uploadArea.innerHTML = `<img src="${currentCroppedImage}" class="showcase-preview" alt="裁剪预览" style="border-radius:50%; max-width:200px; margin:0 auto; display:block;">`;
        });
    });
    
    document.getElementById('saveShowcaseBtn').addEventListener('click', function(){
        if(!currentShowcaseImage) return;
        const description = document.getElementById('showcaseDesc').value.trim();
        const date = document.getElementById('showcaseDate').value;
        const roleId = document.getElementById('showcaseRole').value;
        if(!description) return alert('请输入描述');
        if(!date) return alert('请选择日期');
        
        const item = {
            id: 'sc_' + Date.now(),
            imageBase64: currentShowcaseImage,
            croppedImageBase64: currentShowcaseStyle === 'badge' ? (currentCroppedImage || currentShowcaseImage) : null,
            description,
            date,
            roleId: roleId || null,
            style: currentShowcaseStyle,
            rotation: getRandomRotation(),
            positionX: null,
            positionY: null,
            createdAt: Date.now()
        };
        
        const sizeKB = Math.round((JSON.stringify(item).length * 3) / 4 / 1024);
        const totalItems = loadShowcaseItems().length + 1;
        if(sizeKB > 200){
            if(!confirm(`图片较大（约${sizeKB}KB），可能会占用较多存储空间。确定保存吗？`)) return;
        }
        if(totalItems > 50){
            if(!confirm(`已保存${totalItems - 1}张图片，建议定期清理旧数据。确定继续保存吗？`)) return;
        }
        
        saveShowcaseItem(item);
        currentShowcaseImage = null;
        currentCroppedImage = null;
        closeModal();
        if(document.getElementById('tab-showcase').classList.contains('active')){
            renderShowcaseGrid();
        }
        alert('✨ 奇遇记录已保存！');
    });
}

function showShowcaseDetail(id){
    const items = loadShowcaseItems();
    const item = items.find(i => i.id === id);
    if(!item) return;
    const role = appRoles.find(r => r.id === item.roleId);
    const styleName = item.style === 'badge' ? '吧唧' : '拍立得';
    
    const overlay = document.createElement('div');
    overlay.className = 'showcase-detail-overlay';
    overlay.onclick = function(e){
        if(e.target === overlay || e.target.closest('.showcase-detail-close')) document.body.removeChild(overlay);
    };
    overlay.innerHTML = `<div class="showcase-detail-card" onclick="event.stopPropagation()">
        <button class="showcase-detail-close" onclick="this.closest('.showcase-detail-overlay').remove()">×</button>
        <div class="showcase-detail-image-container">
            <img src="${item.imageBase64}" class="showcase-detail-image" alt="${escapeHtml(item.description)}">
        </div>
        <div class="showcase-detail-body">
            <h3 class="showcase-detail-title">${escapeHtml(item.description)}</h3>
            <div class="showcase-detail-meta">
                <div class="showcase-detail-meta-item">
                    <span class="meta-icon">📅</span>
                    <span>${item.date}</span>
                </div>
                ${role ? `
                <div class="showcase-detail-meta-item">
                    <span class="meta-icon">👤</span>
                    <span>${escapeHtml(role.name)}</span>
                </div>` : ''}
                <div class="showcase-detail-meta-item">
                    <span class="meta-icon">${item.style === 'badge' ? '🎖️' : '📷'}</span>
                    <span>${styleName}</span>
                </div>
            </div>
            <span class="showcase-detail-tag">✨ 奇遇记录</span>
        </div>
    </div>`;
    document.body.appendChild(overlay);
    
    document.addEventListener('keydown', function escHandler(e){
        if(e.key === 'Escape'){
            if(overlay.parentNode) document.body.removeChild(overlay);
            document.removeEventListener('keydown', escHandler);
        }
    });
}

init();