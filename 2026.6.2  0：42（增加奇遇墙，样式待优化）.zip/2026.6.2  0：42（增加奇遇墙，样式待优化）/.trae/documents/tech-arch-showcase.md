## 1. Architecture Design

```mermaid
graph TD
    UI[用户界面层] --> Logic[业务逻辑层]
    Logic --> Storage[数据存储层]
    
    subgraph UI
        Nav[导航栏Tab]
        Board[洞洞板背景]
        Badge[吧唧卡片]
        Polaroid[拍立得卡片]
        Pin[图钉删除按钮]
        Cropper[图片裁剪器]
        Modal[模态框组件]
        FAB[悬浮按钮菜单]
    end
    
    subgraph Logic
        Compress[图片压缩引擎]
        Crop[图片裁剪引擎]
        Drag[拖拽控制器]
        Physics[物理掉落引擎]
        CRUD[CRUD操作]
        Render[渲染引擎]
        Rotate[随机旋转计算]
    end
    
    subgraph Storage
        LS[localStorage]
    end
    
    style LS fill:#f9f,stroke:#333,stroke-width:2px
```

## 2. Technology Description
- 前端：原生HTML5 + CSS3 + JavaScript（ES6+）
- 无框架依赖，保持项目轻量级
- 图片处理：Canvas API 实现压缩和裁剪
- 存储：localStorage（key: showcase_items）
- CSS3 变换：transform translate/rotate 实现位置和旋转
- 拖拽：原生鼠标/触摸事件实现
- 物理动画：requestAnimationFrame 实现帧动画
- 与现有应用无缝集成，沿用既有样式变量和组件

## 3. Integration Points
### 3.1 导航栏扩展
- 位置：index.html 导航栏，在"设置"Tab前插入"✨ 奇遇"
- ID: tab-showcase
- 点击事件：调用 switchTab('showcase')

### 3.2 内容区域
- ID: page-showcase
- 默认隐藏，Tab激活时显示
- 包含：洞洞板容器（showcaseBoard）、空状态提示

### 3.3 悬浮菜单扩展
- 在现有FAB菜单中添加"📸 添加奇遇"选项
- 点击事件：调用 showAddShowcaseModal()

## 4. Data Model
### 4.1 数据结构定义

```mermaid
erDiagram
    SHOWCASE_ITEM {
        string id PK "唯一标识"
        string imageBase64 "原始图片base64"
        string croppedImageBase64 "裁剪后的图片base64（吧唧专用）"
        string description "描述文字"
        string date "发生日期 YYYY-MM-DD"
        string roleId FK "关联角色ID（可选）"
        string style "卡片样式 badge/polaroid"
        number rotation "旋转角度 -15~15"
        number positionX "X坐标（相对洞洞板）"
        number positionY "Y坐标（相对洞洞板）"
        number createdAt "创建时间戳"
    }
    
    ROLE {
        string id PK "角色ID"
        string name "角色名称"
    }
    
    SHOWCASE_ITEM }o--|| ROLE : "可选关联"
```

### 4.2 存储格式
```javascript
// localStorage key: 'showcase_items'
[
  {
    id: 'sc_1234567890',
    imageBase64: 'data:image/jpeg;base64,...',
    croppedImageBase64: 'data:image/jpeg;base64,...',
    description: '济苍生！欧气爆棚',
    date: '2026-06-01',
    roleId: 'role_001',
    style: 'badge',
    rotation: 5.2,
    positionX: 120,
    positionY: 80,
    createdAt: 1780320000000
  }
]
```

## 5. Core Functions

| 函数名 | 功能描述 | 参数 | 返回值 |
|--------|---------|------|--------|
| `compressImage(file, maxWidth, quality)` | 图片压缩 | file: File, maxWidth=600, quality=0.7 | Promise<string> base64 |
| `cropImage(imageSrc, x, y, width, height)` | 图片裁剪 | imageSrc, x, y, width, height | Promise<string> base64 |
| `loadShowcaseItems()` | 加载所有数据 | 无 | Array |
| `saveShowcaseItem(item)` | 保存单条记录 | item: Object | void |
| `deleteShowcaseItem(id)` | 删除单条记录 | id: string | void |
| `updateShowcasePosition(id, x, y)` | 更新位置 | id, x, y | void |
| `renderShowcaseGrid()` | 渲染洞洞板 | 无 | void |
| `showAddShowcaseModal()` | 显示添加模态框 | 无 | void |
| `showImageCropper()` | 显示裁剪器 | imageSrc | void |
| `showShowcaseDetail(item)` | 显示详情卡片 | item: Object | void |
| `confirmDeleteShowcase(id)` | 显示删除确认 | id: string | void |
| `playDropAnimation(element, callback)` | 播放掉落动画 | element, callback | void |
| `getRandomRotation()` | 获取随机旋转角度 | min, max | number |
| `getRandomPosition()` | 获取随机位置 | boardWidth, boardHeight | {x, y} |
| `initDraggable(element, onDragEnd)` | 初始化拖拽 | element, onDragEnd | void |

## 6. Image Processing
### 6.1 Compression Algorithm
1. 创建 Image 对象加载用户选择的文件
2. 创建 Canvas，设置最大宽度为 600px，高度按比例计算
3. 使用 `canvas.toDataURL('image/jpeg', 0.7)` 压缩
4. 校验压缩后大小，若超过 150KB 则降低质量重试
5. 返回压缩后的 base64 字符串

### 6.2 Cropping Algorithm
1. 显示裁剪界面，包含原图和可拖拽调整的裁剪框
2. 裁剪框为正方形，初始大小为图片最短边
3. 可拖拽调整位置，滚轮或按钮缩放大小
4. 实时预览裁剪后的吧唧效果
5. 使用 `canvas.drawImage()` 截取指定区域
6. 返回裁剪后的 base64 字符串

## 7. Physics Animation
### 7.1 掉落动画参数
```javascript
const PHYSICS = {
    gravity: 0.5,           // 重力加速度 px/frame²
    bounce: 0.6,            // 弹跳系数
    friction: 0.98,         // 摩擦力
    maxRotationSpeed: 15,   // 最大旋转速度 °/frame
    minDropTime: 1500,      // 最小掉落时间 ms
    fadeOutDuration: 500    // 淡出时间 ms
};
```

### 7.2 动画流程
1. 确认删除后，获取卡片元素
2. 分离图钉元素，作为独立动画对象
3. 设置初始速度和旋转速度
4. 使用 requestAnimationFrame 逐帧更新位置和旋转
5. 检测与窗口底部的碰撞，应用弹跳
6. 水平速度逐渐衰减
7. 落地后开始淡出
8. 动画结束后调用回调删除数据

## 8. Drag and Drop
### 8.1 拖拽实现
1. 鼠标按下（mousedown）时记录初始位置
2. 鼠标移动（mousemove）时更新元素位置
3. 鼠标松开（mouseup）时保存新位置到 localStorage
4. 支持触摸事件（touchstart, touchmove, touchend）
5. 限制拖拽范围在洞洞板内
6. 拖拽时提升 z-index，避免被其他卡片遮挡
7. 拖拽时禁用点击事件，避免误触发详情

## 9. UI Components

### 9.1 洞洞板容器
```html
<div class="showcase-board" id="showcaseBoard">
    <!-- 卡片通过绝对定位放置 -->
</div>
```

### 9.2 吧唧卡片样式
```css
.showcase-badge {
    position: absolute;
    width: 140px;
    height: 140px;
    border-radius: 50%;
    cursor: grab;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    transition: box-shadow 0.2s, transform 0.1s;
}

.showcase-badge:active {
    cursor: grabbing;
    box-shadow: 0 8px 24px rgba(0,0,0,0.4);
}

.showcase-badge .badge-image {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    background-size: cover;
    background-position: center;
}
```

### 9.3 图钉按钮样式
```css
.showcase-pin {
    position: absolute;
    top: -8px;
    left: 50%;
    transform: translateX(-50%);
    width: 28px;
    height: 28px;
    border-radius: 50%;
    background: radial-gradient(circle at 30% 30%, #ff6b6b, #c0392b);
    border: 2px solid #fff;
    box-shadow: 0 2px 6px rgba(0,0,0,0.3);
    cursor: pointer;
    z-index: 10;
    transition: transform 0.2s;
}

.showcase-pin:hover {
    transform: translateX(-50%) scale(1.1);
}

.showcase-pin::after {
    content: '';
    position: absolute;
    top: 25%;
    left: 25%;
    width: 20%;
    height: 20%;
    border-radius: 50%;
    background: rgba(255,255,255,0.6);
}
```

### 9.4 CSS 变量扩展
```css
:root {
    --showcase-gold: #fdcb6e;
    --showcase-wood: #8B7355;
    --showcase-pin-red: #e74c3c;
    --showcase-badge-size: 140px;
}
```

## 10. Performance Considerations
- 图片压缩和裁剪在前端完成，减少存储占用
- CSS transform 实现位置和旋转，性能优秀
- 随机位置和旋转角度在创建时生成并存储，避免每次渲染重复计算
- 物理动画使用 requestAnimationFrame，与浏览器刷新率同步
- 限制最大卡片数量建议在30张以内
- 拖拽时使用 will-change: transform 提升性能
- 提供清理旧数据的功能入口
